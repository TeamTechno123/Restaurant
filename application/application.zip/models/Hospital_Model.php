<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Hospital_Model extends CI_Model{

  function check_login($mobile, $password){
    $this->db->select('*');
    $this->db->where('hospital_user_mobile', $mobile);
    $this->db->where('hospital_user_password', $password);
    $this->db->where('hospital_user_status', '1');
    $this->db->from('hospital_user');
    $query = $this->db->get();
    $result = $query->result_array();
    return $result;
  }

}
?>
