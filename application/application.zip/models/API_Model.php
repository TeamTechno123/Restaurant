<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class API_Model extends CI_Model{

  public function send_sms($mobile_no, $msg){
    $param['uname'] = 'wbcare';
		$param['password'] = '123123';
		$param['sender'] = 'AKCENT';
		$param['receiver'] = $mobile_no;
		$param['route'] = 'TA';
		$param['msgtype'] = 1;
		$param['sms'] = $msg;
		$parameters = http_build_query($param);
		$url="http://msgblast.in/index.php/smsapi/httpapi";
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch,CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
		curl_setopt($ch, CURLOPT_POSTFIELDS,$parameters);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$result = curl_exec($ch);
    // return $result;
		// echo $result;
  }

  function check_login($mobile_no, $password){
    $this->db->select('*');
    $this->db->where('app_user_mobile', $mobile_no);
    $this->db->where('app_user_password', $password);
    $this->db->from('covid_app_user');
    $query = $this->db->get();
    $result = $query->result_array();
    return $result;
  }

}
?>
