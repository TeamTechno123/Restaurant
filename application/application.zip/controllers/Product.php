<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller{
  public function __construct(){
    parent::__construct();
    date_default_timezone_set('Asia/Kolkata');
  }

  public function index(){

  }


/*********************************** Brand *********************************/

  // Add Brand....
  public function brand(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('brand_name', 'Batch Name', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $brand_status = $this->input->post('brand_status');
      if(!isset($brand_status)){ $brand_status = '1'; }
      $save_data = $_POST;
      $save_data['brand_status'] = $brand_status;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['brand_addedby'] = $pharm_user_id;
      $brand_id = $this->Master_Model->save_data('brand', $save_data);

      if($_FILES['brand_image']['name']){
        $time = time();
        $image_name = 'brand_'.$brand_id.'_'.$time;
        $config['upload_path'] = 'assets/images/brand/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['brand_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('brand_image') && $brand_id && $image_name && $ext && $filename){
          $brand_image_up['brand_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('brand_id', $brand_id, 'brand', $brand_image_up);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }
      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Product/brand');
    }

    $data['brand_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','brand_id','DESC','brand');
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Product/brand', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit/Update Brand...
  public function edit_brand($brand_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('brand_name', 'First Name', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $brand_status = $this->input->post('brand_status');
      if(!isset($brand_status)){ $brand_status = '1'; }
      $update_data = $_POST;
      unset($update_data['old_brand_img']);
      $update_data['brand_status'] = $brand_status;
      $update_data['brand_addedby'] = $pharm_user_id;
      $this->Master_Model->update_info('brand_id', $brand_id, 'brand', $update_data);

      if($_FILES['brand_image']['name']){
        $time = time();
        $image_name = 'brand_'.$brand_id.'_'.$time;
        $config['upload_path'] = 'assets/images/brand/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['brand_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('brand_image') && $brand_id && $image_name && $ext && $filename){
          $brand_image_up['brand_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('brand_id', $brand_id, 'brand', $brand_image_up);
          if($_POST['old_brand_img']){ unlink("assets/images/brand/".$_POST['old_brand_img']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Product/brand');
    }

    $brand_info = $this->Master_Model->get_info_arr('brand_id',$brand_id,'brand');
    if(!$brand_info){ header('location:'.base_url().'Product/brand'); }
    $data['update'] = 'update';
    $data['update_brand'] = 'update';
    $data['brand_info'] = $brand_info[0];
    $data['act_link'] = base_url().'Product/edit_brand/'.$brand_id;

    $data['brand_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','brand_id','DESC','brand');
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Product/brand', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  //Delete Brand...
  public function delete_brand($brand_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $brand_info = $this->Master_Model->get_info_arr_fields('brand_image, brand_id', 'brand_id', $brand_id, 'brand');
    if($brand_info){
      $brand_image = $brand_info[0]['brand_image'];
      if($brand_image){ unlink("assets/images/brand/".$brand_image); }
    }
    $this->Master_Model->delete_info('brand_id', $brand_id, 'brand');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Product/brand');
  }

/*********************************** Article Category *********************************/

  // Add Article Category....
  public function article_category(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('article_category_name', 'Batch Name', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $article_category_status = $this->input->post('article_category_status');
      if(!isset($article_category_status)){ $article_category_status = '1'; }
      $save_data = $_POST;
      $save_data['article_category_status'] = $article_category_status;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['article_category_addedby'] = $pharm_user_id;
      $article_category_id = $this->Master_Model->save_data('article_category', $save_data);

      if($_FILES['article_category_image']['name']){
        $time = time();
        $image_name = 'article_category_'.$article_category_id.'_'.$time;
        $config['upload_path'] = 'assets/images/article/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['article_category_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('article_category_image') && $article_category_id && $image_name && $ext && $filename){
          $article_category_image_up['article_category_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('article_category_id', $article_category_id, 'article_category', $article_category_image_up);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }
      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Product/article_category');
    }

    $data['article_category_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','article_category_id','DESC','article_category');
    $data['page'] = 'Article Category';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Product/article_category', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit/Update Article Category...
  public function edit_article_category($article_category_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('article_category_name', 'First Name', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $article_category_status = $this->input->post('article_category_status');
      if(!isset($article_category_status)){ $article_category_status = '1'; }
      $update_data = $_POST;
      unset($update_data['old_article_category_img']);
      $update_data['article_category_status'] = $article_category_status;
      $update_data['article_category_addedby'] = $pharm_user_id;
      $this->Master_Model->update_info('article_category_id', $article_category_id, 'article_category', $update_data);

      if($_FILES['article_category_image']['name']){
        $time = time();
        $image_name = 'article_category_'.$article_category_id.'_'.$time;
        $config['upload_path'] = 'assets/images/article/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['article_category_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('article_category_image') && $article_category_id && $image_name && $ext && $filename){
          $article_category_image_up['article_category_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('article_category_id', $article_category_id, 'article_category', $article_category_image_up);
          if($_POST['old_article_category_img']){ unlink("assets/images/article/".$_POST['old_article_category_img']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Product/article_category');
    }

    $article_category_info = $this->Master_Model->get_info_arr('article_category_id',$article_category_id,'article_category');
    if(!$article_category_info){ header('location:'.base_url().'Product/article_category'); }
    $data['update'] = 'update';
    $data['update_article_category'] = 'update';
    $data['article_category_info'] = $article_category_info[0];
    $data['act_link'] = base_url().'Product/edit_article_category/'.$article_category_id;

    $data['article_category_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','article_category_id','DESC','article_category');
    $data['page'] = 'Article Category';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Product/article_category', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  //Delete Article Category...
  public function delete_article_category($article_category_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $article_category_info = $this->Master_Model->get_info_arr_fields('article_category_image, article_category_id', 'article_category_id', $article_category_id, 'article_category');
    if($article_category_info){
      $article_category_image = $article_category_info[0]['article_category_image'];
      if($article_category_image){ unlink("assets/images/article/".$article_category_image); }
    }
    $this->Master_Model->delete_info('article_category_id', $article_category_id, 'article_category');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Product/article_category');
  }

/*********************************** Article *********************************/

  // Add Article....
  public function article(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('article_name', 'Batch Name', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $article_status = $this->input->post('article_status');
      if(!isset($article_status)){ $article_status = '1'; }
      $save_data = $_POST;
      $save_data['article_status'] = $article_status;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['article_addedby'] = $pharm_user_id;
      $article_id = $this->Master_Model->save_data('article', $save_data);

      if($_FILES['article_image']['name']){
        $time = time();
        $image_name = 'article_'.$article_id.'_'.$time;
        $config['upload_path'] = 'assets/images/article/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['article_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('article_image') && $article_id && $image_name && $ext && $filename){
          $article_image_up['article_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('article_id', $article_id, 'article', $article_image_up);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }
      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Product/article');
    }

    $data['article_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','article_id','DESC','article');
    $data['page'] = 'Article';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Product/article', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit/Update Article...
  public function edit_article($article_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('article_name', 'First Name', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $article_status = $this->input->post('article_status');
      if(!isset($article_status)){ $article_status = '1'; }
      $update_data = $_POST;
      unset($update_data['old_article_img']);
      $update_data['article_status'] = $article_status;
      $update_data['article_addedby'] = $pharm_user_id;
      $this->Master_Model->update_info('article_id', $article_id, 'article', $update_data);

      if($_FILES['article_image']['name']){
        $time = time();
        $image_name = 'article_'.$article_id.'_'.$time;
        $config['upload_path'] = 'assets/images/article/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['article_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('article_image') && $article_id && $image_name && $ext && $filename){
          $article_image_up['article_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('article_id', $article_id, 'article', $article_image_up);
          if($_POST['old_article_img']){ unlink("assets/images/article/".$_POST['old_article_img']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Product/article');
    }

    $article_info = $this->Master_Model->get_info_arr('article_id',$article_id,'article');
    if(!$article_info){ header('location:'.base_url().'Product/article'); }
    $data['update'] = 'update';
    $data['update_article'] = 'update';
    $data['article_info'] = $article_info[0];
    $data['act_link'] = base_url().'Product/edit_article/'.$article_id;

    $data['article_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','article_id','DESC','article');
    $data['page'] = 'Article';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Product/article', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  //Delete Article...
  public function delete_article($article_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $article_info = $this->Master_Model->get_info_arr_fields('article_image, article_id', 'article_id', $article_id, 'article');
    if($article_info){
      $article_image = $article_info[0]['article_image'];
      if($article_image){ unlink("assets/images/article/".$article_image); }
    }
    $this->Master_Model->delete_info('article_id', $article_id, 'article');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Product/article');
  }




/***************************************************************************************************************/
/*********************************************** Hospital ******************************************************/
/***************************************************************************************************************/






/***************************************************************************************************************/
  public function get_sub_category_by_main(){
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $main_category_id = $this->input->post('main_category_id');
    $sub_category_list = $this->Master_Model->get_list_by_id3($pharm_company_id,'main_category_id',$main_category_id,'','','','','sub_category_name','ASC','sub_category');
    echo '<option value="" selected >Select Sub Category (Level-1)</option>';
    foreach ($sub_category_list as $sub_category_list1) {
      echo '<option value="'.$sub_category_list1->sub_category_id.'">'.$sub_category_list1->sub_category_name.'</option>';
    }
  }

  public function get_sub_category_two_by_sub(){
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $sub_category_id = $this->input->post('sub_category_id');
    $sub_category_list = $this->Master_Model->get_list_by_id3($pharm_company_id,'sub_category_id',$sub_category_id,'','','','','sub_category_two_name','ASC','sub_category_two');
    echo '<option value="" selected >Select Sub Category (Level-2)</option>';
    foreach ($sub_category_list as $sub_category_list1) {
      echo '<option value="'.$sub_category_list1->sub_category_two_id.'">'.$sub_category_list1->sub_category_two_name.'</option>';
    }
  }

}
