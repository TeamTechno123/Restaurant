<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Covid_API extends CI_Controller{
  public function __construct(){
    parent::__construct();
    date_default_timezone_set('Asia/Kolkata');
  }

/************************************* SignUp **********************************/

  // SignUp Send OTP...
  public function signup(){
    $otp = mt_rand(100000, 999999);
    $mobile_no = $_REQUEST['app_user_mobile'];
    // $exist = $this->Master_Model->check_duplication('',$mobile_no,'app_user_mobile','covid_app_user');
    // if($exist > 0){
    //   $response["status"] = FALSE;
    //   $response["msg"] = "Mobile Number Exist";
    // } else{
      $save_data = array(
        // 'app_user_fname' => $_REQUEST['app_user_fname'],
        // 'app_user_lname' => $_REQUEST['app_user_lname'],
        // 'app_user_gender' => $_REQUEST['app_user_gender'],
        // 'app_user_address' => $_REQUEST['app_user_address'],
        // 'state_id' => $_REQUEST['state_id'],
        // 'city_id' => $_REQUEST['city_id'],
        // 'app_user_pincode' => $_REQUEST['app_user_pincode'],
        'app_user_mobile' => $_REQUEST['app_user_mobile'],
        // 'app_user_password' => $_REQUEST['app_user_password'],
      );

      $mobile_no = $_REQUEST['app_user_mobile'];
      // $msg = "Welcome to COVID Enquiry. OTP: ".$otp."";
      // $sms_result = $this->API_Model->send_sms($mobile_no, $msg);

      $response["status"] = TRUE;
      $response["msg"] = "OTP sent to your mobile number ".$mobile_no;
      $response["otp"] = $otp;
    // }
    $json_response = json_encode($response,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    echo str_replace('\\/','/',$json_response);
  }

  // Save SignUp...
  public function save_signup(){
    $mobile_no = $_REQUEST['app_user_mobile'];
    $app_user_info = $this->Master_Model->get_info_arr_fields3('app_user_id, state_id, city_id', '', 'app_user_mobile', $mobile_no, '', '', '', '', 'covid_app_user');
    // $exist = $this->Master_Model->check_duplication('',$mobile_no,'app_user_mobile','covid_app_user');
    if($app_user_info){
      $response["status"] = TRUE;
      $response["msg"] = "Mobile Number Registered Successfull";
      $response["app_user_id"] = $app_user_info[0]['app_user_id'];
      $response["state_id"] = $app_user_info[0]['state_id'];
      $response["city_id"] = $app_user_info[0]['city_id'];
    } else{
      $save_data = array(
        // 'app_user_fname' => $_REQUEST['app_user_fname'],
        // 'app_user_lname' => $_REQUEST['app_user_lname'],
        // 'app_user_gender' => $_REQUEST['app_user_gender'],
        // 'app_user_address' => $_REQUEST['app_user_address'],
        // 'state_id' => $_REQUEST['state_id'],
        // 'city_id' => $_REQUEST['city_id'],
        // 'app_user_pincode' => $_REQUEST['app_user_pincode'],
        'app_user_mobile' => $_REQUEST['app_user_mobile'],
        // 'app_user_password' => $_REQUEST['app_user_password'],
      );

      $app_user_id = $this->Master_Model->save_data('covid_app_user', $save_data);

      $response["status"] = TRUE;
      $response["msg"] = "Mobile Number Registered Successfull";
      $response["app_user_id"] = $app_user_id;
      $response["state_id"] = '0';
      $response["city_id"] = '0';
    }
    $json_response = json_encode($response,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    echo str_replace('\\/','/',$json_response);
  }

  /****************************************** User **********************************/
  // Update Profile...
  public function update_profile(){
    $app_user_id = $_REQUEST['app_user_id'];
    $update_data = array(
      'app_user_fname' => $_REQUEST['app_user_fname'],
      'app_user_lname' => $_REQUEST['app_user_lname'],
      'app_user_gender' => $_REQUEST['app_user_gender'],
      'app_user_address' => $_REQUEST['app_user_address'],
      'state_id' => $_REQUEST['state_id'],
      'city_id' => $_REQUEST['city_id'],
      'app_user_pincode' => $_REQUEST['app_user_pincode'],
      'app_user_mobile2' => $_REQUEST['app_user_mobile2'],
    );
    $this->Master_Model->update_info('app_user_id', $app_user_id, 'covid_app_user', $update_data);

    $response["status"] = TRUE;
    $response["msg"] = "Profile Updated Successfull";
    $response["state_id"] = $_REQUEST['state_id'];
    $response["city_id"] = $_REQUEST['city_id'];
    $json_response = json_encode($response,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    echo str_replace('\\/','/',$json_response);
  }

  // Profile...
  public function profile(){
    $app_user_id = $_REQUEST['app_user_id'];
    $fields = "app_user_id, app_user_fname, app_user_lname, app_user_gender, app_user_address, state_id, city_id, app_user_pincode, app_user_mobile, app_user_mobile2";
    $app_user_info = $this->Master_Model->get_info_arr_fields3($fields, '', 'app_user_id', $app_user_id, '', '', '', '', 'covid_app_user');
    if ($app_user_info) {
      $state_info = $this->Master_Model->get_info_arr_fields3('state_name', '', 'state_id', $app_user_info[0]['state_id'], '', '', '', '', 'state');
      $city_info = $this->Master_Model->get_info_arr_fields3('city_name', '', 'city_id', $app_user_info[0]['city_id'], '', '', '', '', 'city');
      $app_user_info[0]['state_name'] = $state_info[0]['state_name'];
      $app_user_info[0]['city_name'] = $city_info[0]['city_name'];
      $response["status"] = TRUE;
      $response["app_user_info"] = $app_user_info[0];
    } else {
      $response["status"] = FALSE;
      $response["app_user_info"] = $app_user_info;
    }
    $json_response = json_encode($response,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    echo str_replace('\\/','/',$json_response);
  }

/*********************************************** Home Page *********************************/
  public function bed_statistic(){
    if(isset($_REQUEST['city_id'])){ $city_id = $_REQUEST['city_id']; }
    else{ $city_id = ''; }

    $regular_bed_cnt = $this->Master_Model->get_sum('','avlb_regular_bed','hospital_status','1','city_id',$city_id,'','','hospital');
    $oxygen_bed_cnt = $this->Master_Model->get_sum('','avlb_oxygen_bed','hospital_status','1','city_id',$city_id,'','','hospital');
    $icu_bed_cnt = $this->Master_Model->get_sum('','avlb_icu_bed','hospital_status','1','city_id',$city_id,'','','hospital');
    $special_bed_cnt = $this->Master_Model->get_sum('','avlb_special_bed','hospital_status','1','city_id',$city_id,'','','hospital');

    if(!$regular_bed_cnt){ $regular_bed_cnt = '0'; }
    if(!$oxygen_bed_cnt){ $oxygen_bed_cnt = '0'; }
    if(!$icu_bed_cnt){ $icu_bed_cnt = '0'; }
    if(!$special_bed_cnt){ $special_bed_cnt = '0'; }

    $data[0]['bed_type_id'] = "1";
    $data[0]['bed_type'] = "Regular Bed";
    $data[0]['count'] = $regular_bed_cnt;
    $data[1]['bed_type_id'] = "2";
    $data[1]['bed_type'] = "Oxygen Bed";
    $data[1]['count'] = $oxygen_bed_cnt;
    $data[2]['bed_type_id'] = "3";
    $data[2]['bed_type'] = "ICU Bed";
    $data[2]['count'] = $icu_bed_cnt;
    $data[3]['bed_type_id'] = "4";
    $data[3]['bed_type'] = "Special Bed";
    $data[3]['count'] = $special_bed_cnt;

    $response["status"] = TRUE;
    $response["bed_statistic"] = $data;
    // $response["oxygen_bed_cnt"] = $oxygen_bed_cnt;
    // $response["icu_bed_cnt"] = $icu_bed_cnt;
    // $response["special_bed_cnt"] = $special_bed_cnt;

    $json_response = json_encode($response,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    echo str_replace('\\/','/',$json_response);
  }

  public function bed_statistic_hospital_list(){
    $bed_type_id = $_REQUEST['bed_type_id'];
    if($bed_type_id == '1'){ $bed_type = 'avlb_regular_bed'; }
    elseif ($bed_type_id == '2') { $bed_type = 'avlb_oxygen_bed'; }
    elseif ($bed_type_id == '3') { $bed_type = 'avlb_icu_bed'; }
    elseif ($bed_type_id == '4') { $bed_type = 'avlb_special_bed'; }
    else{ $bed_type = ''; }

    // $fields = "hospital_id, hospital_name, hospital_address, hospital_longitude, hospital_latitude, hospital_mobile, hospital_mobile2, hospital_email, hospital_est_on, hospital_num_doctors, hospital_num_ambul, hospital_overview, state_id, city_id, hospital_pincode, hospital_num_beds, tot_regular_bed, avlb_regular_bed, tot_oxygen_bed, avlb_oxygen_bed, avlb_icu_bed, avlb_special_bed, hospital_image";
    $hospital_list = $this->Master_Model->get_info_fields3('*', '', 'hospital_type', '1', 'hospital_status', '1', $bed_type.'>', '0', 'hospital');
    if($hospital_list){
      foreach ($hospital_list as $list) {
        $state_info = $this->Master_Model->get_info_arr_fields3('state_name', '', 'state_id', $list->state_id, '', '', '', '', 'state');
        $city_info = $this->Master_Model->get_info_arr_fields3('city_name', '', 'city_id', $list->city_id, '', '', '', '', 'city');
        $list->state_name = $state_info[0]['state_name'];
        $list->city_name = $city_info[0]['city_name'];
      }

      $response["status"] = TRUE;
      $response["hospital_img_path"] = base_url().'assets/images/hospital/';
      $response["hospital_list"] = $hospital_list;
    } else{

      $response["status"] = FALSE;
      $response["hospital_img_path"] = base_url().'assets/images/hospital/';
      $response["hospital_list"] = $hospital_list;
    }
    $json_response = json_encode($response,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    echo str_replace('\\/','/',$json_response);
  }

  public function hospital_list(){
    $hospital_type_id = $_REQUEST['hospital_type_id'];
    // $fields = "hospital_id, hospital_name, hospital_address, hospital_longitude, hospital_latitude, hospital_mobile, hospital_mobile2, hospital_email, hospital_est_on, hospital_num_doctors, hospital_num_ambul, hospital_overview, state_id, city_id, hospital_pincode, avlb_regular_bed, avlb_oxygen_bed, avlb_icu_bed, avlb_special_bed, hospital_image";
    if($hospital_type_id == 3){
      $hospital_list = $this->Master_Model->get_info_fields4('*', '', 'hospital_type != ', '1', 'hospital_type != ', '2', 'hospital_status', '1', '', '', 'hospital_name', 'ASC', 'hospital');
    } else{
      $hospital_list = $this->Master_Model->get_info_fields4('*', '', 'hospital_type', $hospital_type_id, 'hospital_status', '1', '', '', '', '', 'hospital_name', 'ASC', 'hospital');
    }

    if($hospital_list){
      foreach ($hospital_list as $list) {
        $state_info = $this->Master_Model->get_info_arr_fields3('state_name', '', 'state_id', $list->state_id, '', '', '', '', 'state');
        $city_info = $this->Master_Model->get_info_arr_fields3('city_name', '', 'city_id', $list->city_id, '', '', '', '', 'city');
        $list->state_name = $state_info[0]['state_name'];
        $list->city_name = $city_info[0]['city_name'];
      }
      $response["status"] = TRUE;
      $response["hospital_img_path"] = base_url().'assets/images/hospital/';
      $response["hospital_list"] = $hospital_list;
    } else{
      $response["status"] = FALSE;
      $response["hospital_img_path"] = base_url().'assets/images/hospital/';
      $response["hospital_list"] = $hospital_list;
    }
    $json_response = json_encode($response,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    echo str_replace('\\/','/',$json_response);
  }

/************************************* Hospital Profile ******************************/
  // Hospital Details...
  public function hospital_details(){
    $hospital_id = $_REQUEST['hospital_id'];
    $fields = "hospital_id, hospital_name, hospital_address, hospital_longitude, hospital_latitude, hospital_mobile, hospital_mobile2, hospital_email, hospital_est_on, hospital_num_doctors, hospital_num_ambul, hospital_overview, state_id, city_id, hospital_pincode, avlb_regular_bed, avlb_oxygen_bed, avlb_icu_bed, avlb_special_bed, hospital_image";
    $hospital_info = $this->Master_Model->get_info_arr_fields3('*', '', 'hospital_id', $hospital_id, '', '', '', '', 'hospital');
    $package_list = array();
    if($hospital_info){
      $state_info = $this->Master_Model->get_info_arr_fields3('state_name', '', 'state_id', $hospital_info[0]['state_id'], '', '', '', '', 'state');
      $city_info = $this->Master_Model->get_info_arr_fields3('city_name', '', 'city_id', $hospital_info[0]['city_id'], '', '', '', '', 'city');
      $hospital_info[0]['state_name'] = $state_info[0]['state_name'];
      $hospital_info[0]['city_name'] = $city_info[0]['city_name'];
      $package_list = $this->Master_Model->get_list_by_id3('','hospital_id',$hospital_id,'','','','','cov_package_id','DESC','cov_package');
      foreach ($package_list as $package_list1) {
        $package_file_list = $this->Master_Model->get_list_by_id3('','cov_package_id',$package_list1->cov_package_id,'','','','','cov_package_file_id','ASC','cov_package_file');
        $package_list1->package_file_list = $package_file_list;
      }

      $str_arr = explode (",", $hospital_info[0]['hospital_facility']);
      $i = 0;
      $facility_list = array();
      foreach ($str_arr as $hospital_facility) {
        $facility_info = $this->Master_Model->get_info_arr_fields3('facility_id, facility_name, facility_image', '', 'facility_id', $hospital_facility, 'facility_status', '1', '', '', 'facility');
        // $product_attribute_list = $this->API_Model->product_attribute_list($product_id);
        // $pro_info[0]['product_attribute_list'] = $product_attribute_list;
        $facility_list[$i] = $facility_info[0];
        $i++;
      }
      // $list->facility_list = $facility_list;


      // $facility_list =

      $response["status"] = TRUE;
      $response["hospital_img_path"] = base_url().'assets/images/hospital/';
      $response["facility_img_path"] = base_url().'assets/images/facility/';
      $response["package_file_path"] = base_url().'assets/images/cov_package/';
      $response["hospital_details"] = $hospital_info[0];
      $response["facility_list"] = $facility_list;
      $response["package_list"] = $package_list;
    } else{
      $response["status"] = FALSE;
      $response["hospital_img_path"] = base_url().'assets/images/hospital/';
      $response["facility_img_path"] = base_url().'assets/images/facility/';
      $response["package_file_path"] = base_url().'assets/images/cov_package/';
      $response["hospital_details"] = $hospital_info;
      $response["facility_list"] = $facility_list;
      $response["package_list"] = $package_list;
    }

    $json_response = json_encode($response,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    echo str_replace('\\/','/',$json_response);
  }

/********************************************** Treatment List *******************************/

   public function treatment_list(){
     $treatment_list = $this->Master_Model->get_list_by_id3('','cov_treatment_status','1','','','','','cov_treatment_id','ASC','cov_treatment');
     if($treatment_list){
       $response["status"] = TRUE;
       $response["treatment_list"] = $treatment_list;
     } else{
       $response["status"] = FALSE;
       $response["treatment_list"] = $treatment_list;
     }
     $json_response = json_encode($response,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
     echo str_replace('\\/','/',$json_response);
   }

   public function article_category_list(){
     $article_category_list = $this->Master_Model->get_list_by_id3('','article_category_status','1','','','','','article_category_id','ASC','article_category');
     if($article_category_list){
       $response["status"] = TRUE;
       $response["article_img_path"] = base_url().'assets/images/article/';
       $response["article_category_list"] = $article_category_list;
     } else{
       $response["status"] = FALSE;
       $response["article_img_path"] = base_url().'assets/images/article/';
       $response["article_category_list"] = $article_category_list;
     }
     $json_response = json_encode($response,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
     echo str_replace('\\/','/',$json_response);
   }

   public function article_list(){
     $article_category_id = $_REQUEST['article_category_id'];
     $article_list = $this->Master_Model->get_list_by_id3('','article_status','1','article_category_id',$article_category_id,'','','article_id','ASC','article');
     if($article_list){
       $response["status"] = TRUE;
       $response["article_img_path"] = base_url().'assets/images/article/';
       $response["article_list"] = $article_list;
     } else{
       $response["status"] = FALSE;
       $response["article_img_path"] = base_url().'assets/images/article/';
       $response["article_list"] = $article_list;
     }
     $json_response = json_encode($response,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
     echo str_replace('\\/','/',$json_response);
   }

   public function article_details(){
     $article_id = $_REQUEST['article_id'];
     $article_details = $this->Master_Model->get_info_arr('article_id', $article_id, 'article');
     if($article_details){
       $response["status"] = TRUE;
       $response["article_img_path"] = base_url().'assets/images/article/';
       $response["article_details"] = $article_details[0];
     } else{
       $response["status"] = FALSE;
       $response["article_img_path"] = base_url().'assets/images/article/';
       $response["article_details"] = $article_details;
     }
     $json_response = json_encode($response,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
     echo str_replace('\\/','/',$json_response);
   }

/******************************** Master List **********************/
  public function state_list(){
    $state_list = $this->Master_Model->get_list_by_id3('','','','','','','','state_name','ASC','state');
    if($state_list){
      $response["status"] = TRUE;
      $response["state_list"] = $state_list;
    } else{
      $response["status"] = FALSE;
      $response["state_list"] = $state_list;
    }
    $json_response = json_encode($response,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    echo str_replace('\\/','/',$json_response);
  }

  public function city_list(){
    $state_id = $_REQUEST['state_id'];
    $city_list = $this->Master_Model->get_list_by_id3('','state_id',$state_id,'','','','','city_name','ASC','city');
    if($city_list){
      $response["status"] = TRUE;
      $response["city_list"] = $city_list;
    } else{
      $response["status"] = FALSE;
      $response["city_list"] = $city_list;
    }
    $json_response = json_encode($response,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    echo str_replace('\\/','/',$json_response);
  }

}
?>
