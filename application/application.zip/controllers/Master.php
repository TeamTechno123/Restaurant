<?php
defined('BASEPATH') OR exit('No direct script access allowed');

  class Master extends CI_Controller{
    public function __construct(){
      parent::__construct();
      date_default_timezone_set('Asia/Kolkata');
    }

    public function index(){

    }


/********************************* Unit ***********************************/
  // Add Unit...
  public function unit(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' || $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('unit_name', 'Unit Name', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $unit_status = $this->input->post('unit_status');
      if(!isset($unit_status)){ $unit_status = '1'; }
      $save_data = $_POST;
      $save_data['unit_status'] = $unit_status;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['unit_addedby'] = $pharm_user_id;
      $user_id = $this->Master_Model->save_data('unit', $save_data);

      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Master/unit');
    }

    $data['unit_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','unit_id','ASC','unit');
    $data['page'] = 'Unit';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/unit', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit/Update Unit...
  public function edit_unit($unit_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' || $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('unit_name', 'Unit Name', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $unit_status = $this->input->post('unit_status');
      if(!isset($unit_status)){ $unit_status = '1'; }
      $update_data = $_POST;
      $update_data['unit_status'] = $unit_status;
      $update_data['unit_addedby'] = $pharm_user_id;
      $this->Master_Model->update_info('unit_id', $unit_id, 'unit', $update_data);

      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Master/unit');
    }

    $unit_info = $this->Master_Model->get_info_arr('unit_id',$unit_id,'unit');
    if(!$unit_info){ header('location:'.base_url().'Master/unit'); }
    $data['update'] = 'update';
    $data['update_unit'] = 'update';
    $data['unit_info'] = $unit_info[0];
    $data['act_link'] = base_url().'Master/edit_unit/'.$unit_id;

    $data['unit_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','unit_id','ASC','unit');
    $data['page'] = 'Unit';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/unit', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  //Delete Unit...
  public function delete_unit($unit_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' || $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $this->Master_Model->delete_info('unit_id', $unit_id, 'unit');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Master/unit');
  }

/********************************* SLider ***********************************/

  // Add Slider...
  public function slider(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('slider_name', 'slider title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $slider_status = $this->input->post('slider_status');
      if(!isset($slider_status)){ $slider_status = '1'; }
      $save_data = $_POST;
      $save_data['slider_status'] = $slider_status;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['slider_addedby'] = $pharm_user_id;
      $save_data['slider_date'] = date('d-m-Y');
      $save_data['slider_time'] = date('h:i:s A');
      $slider_id = $this->Master_Model->save_data('slider', $save_data);

      if($_FILES['slider_image']['name']){
        $time = time();
        $image_name = 'slider_'.$slider_id.'_'.$time;
        $config['upload_path'] = 'assets/images/slider/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['slider_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('slider_image') && $slider_id && $image_name && $ext && $filename){
          $slider_image_up['slider_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('slider_id', $slider_id, 'slider', $slider_image_up);
          // unlink("assets/images/tours/".$slider_image_old);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }
      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Master/slider');
    }
    $data['slider_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','slider_id','DESC','slider');
    $data['page'] = 'Slider';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/slider', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit Slider...
  public function edit_slider($slider_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('slider_name', 'slider title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $slider_status = $this->input->post('slider_status');
      if(!isset($slider_status)){ $slider_status = '1'; }
      $update_data = $_POST;
      unset($update_data['old_slider_img']);
      $update_data['slider_status'] = $slider_status;
      $update_data['slider_addedby'] = $pharm_user_id;
      $update_data['slider_date'] = date('d-m-Y');
      $update_data['slider_time'] = date('h:i:s A');
      $this->Master_Model->update_info('slider_id', $slider_id, 'slider', $update_data);

      if($_FILES['slider_image']['name']){
        $time = time();
        $image_name = 'slider_'.$slider_id.'_'.$time;
        $config['upload_path'] = 'assets/images/slider/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['slider_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('slider_image') && $slider_id && $image_name && $ext && $filename){
          $slider_image_up['slider_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('slider_id', $slider_id, 'slider', $slider_image_up);
          if($_POST['old_slider_img']){ unlink("assets/images/slider/".$_POST['old_slider_img']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }
      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Master/slider');
    }
    $slider_info = $this->Master_Model->get_info_arr('slider_id',$slider_id,'slider');
    if(!$slider_info){ header('location:'.base_url().'Master/slider'); }
    $data['update'] = 'update';
    $data['update_slider'] = 'update';
    $data['slider_info'] = $slider_info[0];
    $data['act_link'] = base_url().'Master/edit_slider/'.$slider_id;

    $data['slider_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','slider_id','DESC','slider');
    $data['page'] = 'Slider';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/slider', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Delete Slider...
  public function delete_slider($slider_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $slider_info = $this->Master_Model->get_info_arr_fields('slider_image, slider_id', 'slider_id', $slider_id, 'slider');
    if($slider_info){
      $slider_image = $slider_info[0]['slider_image'];
      if($slider_image){ unlink("assets/images/slider/".$slider_image); }
    }
    $this->Master_Model->delete_info('slider_id', $slider_id, 'slider');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Master/slider');
  }

/********************************* Salt ***********************************/
  // Add Salt...
  public function salt(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' || $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('salt_name', 'Salt Name', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $salt_status = $this->input->post('salt_status');
      if(!isset($salt_status)){ $salt_status = '1'; }
      $save_data = $_POST;
      $save_data['salt_status'] = $salt_status;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['salt_addedby'] = $pharm_user_id;
      $user_id = $this->Master_Model->save_data('salt', $save_data);

      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Master/salt');
    }

    $data['salt_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','salt_id','ASC','salt');
    $data['page'] = 'Salt';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/salt', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit/Update Salt...
  public function edit_salt($salt_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' || $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('salt_name', 'Salt Name', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $salt_status = $this->input->post('salt_status');
      if(!isset($salt_status)){ $salt_status = '1'; }
      $update_data = $_POST;
      $update_data['salt_status'] = $salt_status;
      $update_data['salt_addedby'] = $pharm_user_id;
      $this->Master_Model->update_info('salt_id', $salt_id, 'salt', $update_data);

      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Master/salt');
    }

    $salt_info = $this->Master_Model->get_info_arr('salt_id',$salt_id,'salt');
    if(!$salt_info){ header('location:'.base_url().'Master/salt'); }
    $data['update'] = 'update';
    $data['update_salt'] = 'update';
    $data['salt_info'] = $salt_info[0];
    $data['act_link'] = base_url().'Master/edit_salt/'.$salt_id;

    $data['salt_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','salt_id','ASC','salt');
    $data['page'] = 'Salt';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/salt', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  //Delete Salt...
  public function delete_salt($salt_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' || $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $this->Master_Model->delete_info('salt_id', $salt_id, 'salt');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Master/salt');
  }

/********************************* Packing ***********************************/
  // Add Packing...
  public function packing(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' || $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('packing_name', 'Packing Name', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $packing_status = $this->input->post('packing_status');
      if(!isset($packing_status)){ $packing_status = '1'; }
      $save_data = $_POST;
      $save_data['packing_status'] = $packing_status;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['packing_addedby'] = $pharm_user_id;
      $user_id = $this->Master_Model->save_data('packing', $save_data);

      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Master/packing');
    }

    $data['packing_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','packing_id','ASC','packing');
    $data['page'] = 'Packing';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/packing', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit/Update Packing...
  public function edit_packing($packing_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' || $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('packing_name', 'Packing Name', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $packing_status = $this->input->post('packing_status');
      if(!isset($packing_status)){ $packing_status = '1'; }
      $update_data = $_POST;
      $update_data['packing_status'] = $packing_status;
      $update_data['packing_addedby'] = $pharm_user_id;
      $this->Master_Model->update_info('packing_id', $packing_id, 'packing', $update_data);

      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Master/packing');
    }

    $packing_info = $this->Master_Model->get_info_arr('packing_id',$packing_id,'packing');
    if(!$packing_info){ header('location:'.base_url().'Master/packing'); }
    $data['update'] = 'update';
    $data['update_packing'] = 'update';
    $data['packing_info'] = $packing_info[0];
    $data['act_link'] = base_url().'Master/edit_packing/'.$packing_id;

    $data['packing_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','packing_id','ASC','packing');
    $data['page'] = 'Packing';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/packing', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  //Delete Packing...
  public function delete_packing($packing_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' || $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $this->Master_Model->delete_info('packing_id', $packing_id, 'packing');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Master/packing');
  }

/********************************* Education Speciality ***********************************/
  // Add Education Speciality...
  public function edu_speciality(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' || $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('edu_speciality_name', 'Education Speciality Name', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $edu_speciality_status = $this->input->post('edu_speciality_status');
      if(!isset($edu_speciality_status)){ $edu_speciality_status = '1'; }
      $save_data = $_POST;
      $save_data['edu_speciality_status'] = $edu_speciality_status;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['edu_speciality_addedby'] = $pharm_user_id;
      $user_id = $this->Master_Model->save_data('edu_speciality', $save_data);

      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Master/edu_speciality');
    }

    $data['edu_speciality_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','edu_speciality_id','ASC','edu_speciality');
    $data['page'] = 'Education Speciality';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/edu_speciality', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit/Update Education Speciality...
  public function edit_edu_speciality($edu_speciality_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' || $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('edu_speciality_name', 'Education Speciality Name', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $edu_speciality_status = $this->input->post('edu_speciality_status');
      if(!isset($edu_speciality_status)){ $edu_speciality_status = '1'; }
      $update_data = $_POST;
      $update_data['edu_speciality_status'] = $edu_speciality_status;
      $update_data['edu_speciality_addedby'] = $pharm_user_id;
      $this->Master_Model->update_info('edu_speciality_id', $edu_speciality_id, 'edu_speciality', $update_data);

      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Master/edu_speciality');
    }

    $edu_speciality_info = $this->Master_Model->get_info_arr('edu_speciality_id',$edu_speciality_id,'edu_speciality');
    if(!$edu_speciality_info){ header('location:'.base_url().'Master/edu_speciality'); }
    $data['update'] = 'update';
    $data['update_edu_speciality'] = 'update';
    $data['edu_speciality_info'] = $edu_speciality_info[0];
    $data['act_link'] = base_url().'Master/edit_edu_speciality/'.$edu_speciality_id;

    $data['edu_speciality_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','edu_speciality_id','ASC','edu_speciality');
    $data['page'] = 'Education Speciality';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/edu_speciality', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  //Delete Education Speciality...
  public function delete_edu_speciality($edu_speciality_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' || $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $this->Master_Model->delete_info('edu_speciality_id', $edu_speciality_id, 'edu_speciality');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Master/edu_speciality');
  }

/********************************* Education Stream ***********************************/
  // Add Education Stream...
  public function edu_stream(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' || $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('edu_stream_name', 'Education Stream Name', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $edu_stream_status = $this->input->post('edu_stream_status');
      if(!isset($edu_stream_status)){ $edu_stream_status = '1'; }
      $save_data = $_POST;
      $save_data['edu_stream_status'] = $edu_stream_status;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['edu_stream_addedby'] = $pharm_user_id;
      $user_id = $this->Master_Model->save_data('edu_stream', $save_data);

      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Master/edu_stream');
    }

    $data['edu_stream_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','edu_stream_id','ASC','edu_stream');
    $data['page'] = 'Education Stream';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/edu_stream', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit/Update Education Stream...
  public function edit_edu_stream($edu_stream_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' || $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('edu_stream_name', 'Education Stream Name', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $edu_stream_status = $this->input->post('edu_stream_status');
      if(!isset($edu_stream_status)){ $edu_stream_status = '1'; }
      $update_data = $_POST;
      $update_data['edu_stream_status'] = $edu_stream_status;
      $update_data['edu_stream_addedby'] = $pharm_user_id;
      $this->Master_Model->update_info('edu_stream_id', $edu_stream_id, 'edu_stream', $update_data);

      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Master/edu_stream');
    }

    $edu_stream_info = $this->Master_Model->get_info_arr('edu_stream_id',$edu_stream_id,'edu_stream');
    if(!$edu_stream_info){ header('location:'.base_url().'Master/edu_stream'); }
    $data['update'] = 'update';
    $data['update_edu_stream'] = 'update';
    $data['edu_stream_info'] = $edu_stream_info[0];
    $data['act_link'] = base_url().'Master/edit_edu_stream/'.$edu_stream_id;

    $data['edu_stream_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','edu_stream_id','ASC','edu_stream');
    $data['page'] = 'Education Stream';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/edu_stream', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  //Delete Education Stream...
  public function delete_edu_stream($edu_stream_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' || $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $this->Master_Model->delete_info('edu_stream_id', $edu_stream_id, 'edu_stream');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Master/edu_stream');
  }


/********************************* Advertise Banner ***********************************/

  // Add Advertise Banner...
  public function advt_banner(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('advt_banner_name', 'advt_banner title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $advt_banner_status = $this->input->post('advt_banner_status');
      if(!isset($advt_banner_status)){ $advt_banner_status = '1'; }
      $save_data = $_POST;
      $save_data['advt_banner_status'] = $advt_banner_status;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['advt_banner_addedby'] = $pharm_user_id;
      $advt_banner_id = $this->Master_Model->save_data('advt_banner', $save_data);

      if($_FILES['advt_banner_image']['name']){
        $time = time();
        $image_name = 'advt_banner_'.$advt_banner_id.'_'.$time;
        $config['upload_path'] = 'assets/images/advt_banner/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['advt_banner_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('advt_banner_image') && $advt_banner_id && $image_name && $ext && $filename){
          $advt_banner_image_up['advt_banner_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('advt_banner_id', $advt_banner_id, 'advt_banner', $advt_banner_image_up);
          // unlink("assets/images/tours/".$advt_banner_image_old);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }
      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Master/advt_banner');
    }

    $data['advt_banner_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','advt_banner_id','DESC','advt_banner');
    $data['page'] = 'Advertise Banner';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/advt_banner', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit Advertise Banner...
  public function edit_advt_banner($advt_banner_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('advt_banner_name', 'advt_banner title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $advt_banner_status = $this->input->post('advt_banner_status');
      if(!isset($advt_banner_status)){ $advt_banner_status = '1'; }
      $update_data = $_POST;
      unset($update_data['old_advt_banner_img']);
      $update_data['advt_banner_status'] = $advt_banner_status;
      $update_data['advt_banner_addedby'] = $pharm_user_id;
      $this->Master_Model->update_info('advt_banner_id', $advt_banner_id, 'advt_banner', $update_data);

      if($_FILES['advt_banner_image']['name']){
        $time = time();
        $image_name = 'advt_banner_'.$advt_banner_id.'_'.$time;
        $config['upload_path'] = 'assets/images/advt_banner/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['advt_banner_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('advt_banner_image') && $advt_banner_id && $image_name && $ext && $filename){
          $advt_banner_image_up['advt_banner_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('advt_banner_id', $advt_banner_id, 'advt_banner', $advt_banner_image_up);
          if($_POST['old_advt_banner_img']){ unlink("assets/images/advt_banner/".$_POST['old_advt_banner_img']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }
      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Master/advt_banner');
    }
    $advt_banner_info = $this->Master_Model->get_info_arr('advt_banner_id',$advt_banner_id,'advt_banner');
    if(!$advt_banner_info){ header('location:'.base_url().'Master/advt_banner'); }
    $data['update'] = 'update';
    $data['update_advt_banner'] = 'update';
    $data['advt_banner_info'] = $advt_banner_info[0];
    $data['act_link'] = base_url().'Master/edit_advt_banner/'.$advt_banner_id;

    $data['advt_banner_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','advt_banner_id','DESC','advt_banner');
    $data['page'] = 'Advertise Banner';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/advt_banner', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Delete Advertise Banner...
  public function delete_advt_banner($advt_banner_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $advt_banner_info = $this->Master_Model->get_info_arr_fields('advt_banner_image, advt_banner_id', 'advt_banner_id', $advt_banner_id, 'advt_banner');
    if($advt_banner_info){
      $advt_banner_image = $advt_banner_info[0]['advt_banner_image'];
      if($advt_banner_image){ unlink("assets/images/advt_banner/".$advt_banner_image); }
    }
    $this->Master_Model->delete_info('advt_banner_id', $advt_banner_id, 'advt_banner');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Master/advt_banner');
  }


/********************************* Facility ***********************************/

  // Add Facility...
  public function facility(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('facility_name', 'facility title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $facility_status = $this->input->post('facility_status');
      if(!isset($facility_status)){ $facility_status = '1'; }
      $save_data = $_POST;
      $save_data['facility_status'] = $facility_status;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['facility_addedby'] = $pharm_user_id;
      $facility_id = $this->Master_Model->save_data('facility', $save_data);

      if($_FILES['facility_image']['name']){
        $time = time();
        $image_name = 'facility_'.$facility_id.'_'.$time;
        $config['upload_path'] = 'assets/images/facility/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['facility_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('facility_image') && $facility_id && $image_name && $ext && $filename){
          $facility_image_up['facility_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('facility_id', $facility_id, 'facility', $facility_image_up);
          // unlink("assets/images/tours/".$facility_image_old);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }
      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Master/facility');
    }

    $data['facility_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','facility_id','DESC','facility');
    $data['page'] = 'Facility';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/facility', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit Facility...
  public function edit_facility($facility_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('facility_name', 'facility title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $facility_status = $this->input->post('facility_status');
      if(!isset($facility_status)){ $facility_status = '1'; }
      $update_data = $_POST;
      unset($update_data['old_facility_img']);
      $update_data['facility_status'] = $facility_status;
      $update_data['facility_addedby'] = $pharm_user_id;
      $this->Master_Model->update_info('facility_id', $facility_id, 'facility', $update_data);

      if($_FILES['facility_image']['name']){
        $time = time();
        $image_name = 'facility_'.$facility_id.'_'.$time;
        $config['upload_path'] = 'assets/images/facility/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['facility_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('facility_image') && $facility_id && $image_name && $ext && $filename){
          $facility_image_up['facility_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('facility_id', $facility_id, 'facility', $facility_image_up);
          if($_POST['old_facility_img']){ unlink("assets/images/facility/".$_POST['old_facility_img']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }
      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Master/facility');
    }
    $facility_info = $this->Master_Model->get_info_arr('facility_id',$facility_id,'facility');
    if(!$facility_info){ header('location:'.base_url().'Master/facility'); }
    $data['update'] = 'update';
    $data['update_facility'] = 'update';
    $data['facility_info'] = $facility_info[0];
    $data['act_link'] = base_url().'Master/edit_facility/'.$facility_id;

    $data['facility_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','facility_id','DESC','facility');
    $data['page'] = 'Facility';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/facility', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Delete Facility...
  public function delete_facility($facility_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $facility_info = $this->Master_Model->get_info_arr_fields('facility_image, facility_id', 'facility_id', $facility_id, 'facility');
    if($facility_info){
      $facility_image = $facility_info[0]['facility_image'];
      if($facility_image){ unlink("assets/images/facility/".$facility_image); }
    }
    $this->Master_Model->delete_info('facility_id', $facility_id, 'facility');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Master/facility');
  }


/********************************* Safety ***********************************/

  // Add Safety...
  public function safety(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('safety_name', 'safety title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $safety_status = $this->input->post('safety_status');
      if(!isset($safety_status)){ $safety_status = '1'; }
      $save_data = $_POST;
      $save_data['safety_status'] = $safety_status;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['safety_addedby'] = $pharm_user_id;
      $safety_id = $this->Master_Model->save_data('safety', $save_data);

      if($_FILES['safety_image']['name']){
        $time = time();
        $image_name = 'safety_'.$safety_id.'_'.$time;
        $config['upload_path'] = 'assets/images/safety/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['safety_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('safety_image') && $safety_id && $image_name && $ext && $filename){
          $safety_image_up['safety_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('safety_id', $safety_id, 'safety', $safety_image_up);
          // unlink("assets/images/tours/".$safety_image_old);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      if($_FILES['safety_icon']['name']){
        $time = time();
        $image_name = 'safety_icon_'.$safety_id.'_'.$time;
        $config['upload_path'] = 'assets/images/safety/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['safety_icon']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('safety_icon') && $safety_id && $image_name && $ext && $filename){
          $safety_icon_up['safety_icon'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('safety_id', $safety_id, 'safety', $safety_icon_up);
          // unlink("assets/images/tours/".$safety_icon_old);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Master/safety');
    }
    $data['safety_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','safety_id','DESC','safety');
    $data['page'] = 'Safety';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/safety', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit Safety...
  public function edit_safety($safety_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('safety_name', 'safety title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $safety_status = $this->input->post('safety_status');
      if(!isset($safety_status)){ $safety_status = '1'; }
      $update_data = $_POST;
      unset($update_data['old_safety_img']);
      unset($update_data['old_safety_icon']);
      $update_data['safety_status'] = $safety_status;
      $update_data['safety_addedby'] = $pharm_user_id;
      $this->Master_Model->update_info('safety_id', $safety_id, 'safety', $update_data);

      if($_FILES['safety_image']['name']){
        $time = time();
        $image_name = 'safety_'.$safety_id.'_'.$time;
        $config['upload_path'] = 'assets/images/safety/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['safety_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('safety_image') && $safety_id && $image_name && $ext && $filename){
          $safety_image_up['safety_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('safety_id', $safety_id, 'safety', $safety_image_up);
          if($_POST['old_safety_img']){ unlink("assets/images/safety/".$_POST['old_safety_img']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      if($_FILES['safety_icon']['name']){
        $time = time();
        $image_name = 'safety_icon'.$safety_id.'_'.$time;
        $config['upload_path'] = 'assets/images/safety/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['safety_icon']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('safety_icon') && $safety_id && $image_name && $ext && $filename){
          $safety_icon_up['safety_icon'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('safety_id', $safety_id, 'safety', $safety_icon_up);
          if($_POST['old_safety_icon']){ unlink("assets/images/safety/".$_POST['old_safety_icon']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }
      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Master/safety');
    }
    $safety_info = $this->Master_Model->get_info_arr('safety_id',$safety_id,'safety');
    if(!$safety_info){ header('location:'.base_url().'Master/safety'); }
    $data['update'] = 'update';
    $data['update_safety'] = 'update';
    $data['safety_info'] = $safety_info[0];
    $data['act_link'] = base_url().'Master/edit_safety/'.$safety_id;

    $data['safety_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','safety_id','DESC','safety');
    $data['page'] = 'Safety';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/safety', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Delete Safety...
  public function delete_safety($safety_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $safety_info = $this->Master_Model->get_info_arr_fields('safety_image, safety_icon, safety_id', 'safety_id', $safety_id, 'safety');
    if($safety_info){
      $safety_image = $safety_info[0]['safety_image'];
      if($safety_image){ unlink("assets/images/safety/".$safety_image); }
      $safety_icon = $safety_info[0]['safety_icon'];
      if($safety_icon){ unlink("assets/images/safety/".$safety_icon); }
    }
    $this->Master_Model->delete_info('safety_id', $safety_id, 'safety');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Master/safety');
  }


/********************************* Service ***********************************/

  // Add Service...
  public function service(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('service_name', 'service title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $service_status = $this->input->post('service_status');
      if(!isset($service_status)){ $service_status = '1'; }
      $save_data = $_POST;
      $save_data['service_status'] = $service_status;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['service_addedby'] = $pharm_user_id;
      $service_id = $this->Master_Model->save_data('service', $save_data);

      if($_FILES['service_image']['name']){
        $time = time();
        $image_name = 'service_'.$service_id.'_'.$time;
        $config['upload_path'] = 'assets/images/service/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['service_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('service_image') && $service_id && $image_name && $ext && $filename){
          $service_image_up['service_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('service_id', $service_id, 'service', $service_image_up);
          // unlink("assets/images/tours/".$service_image_old);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      if($_FILES['service_icon']['name']){
        $time = time();
        $image_name = 'service_icon_'.$service_id.'_'.$time;
        $config['upload_path'] = 'assets/images/service/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['service_icon']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('service_icon') && $service_id && $image_name && $ext && $filename){
          $service_icon_up['service_icon'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('service_id', $service_id, 'service', $service_icon_up);
          // unlink("assets/images/tours/".$service_icon_old);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Master/service');
    }

    $data['service_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','service_id','DESC','service');
    $data['page'] = 'Service';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/service', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit Service...
  public function edit_service($service_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('service_name', 'service title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $service_status = $this->input->post('service_status');
      if(!isset($service_status)){ $service_status = '1'; }
      $update_data = $_POST;
      unset($update_data['old_service_img']);
      unset($update_data['old_service_icon']);
      $update_data['service_status'] = $service_status;
      $update_data['service_addedby'] = $pharm_user_id;
      $this->Master_Model->update_info('service_id', $service_id, 'service', $update_data);

      if($_FILES['service_image']['name']){
        $time = time();
        $image_name = 'service_'.$service_id.'_'.$time;
        $config['upload_path'] = 'assets/images/service/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['service_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('service_image') && $service_id && $image_name && $ext && $filename){
          $service_image_up['service_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('service_id', $service_id, 'service', $service_image_up);
          if($_POST['old_service_img']){ unlink("assets/images/service/".$_POST['old_service_img']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      if($_FILES['service_icon']['name']){
        $time = time();
        $image_name = 'service_icon'.$service_id.'_'.$time;
        $config['upload_path'] = 'assets/images/service/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['service_icon']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('service_icon') && $service_id && $image_name && $ext && $filename){
          $service_icon_up['service_icon'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('service_id', $service_id, 'service', $service_icon_up);
          if($_POST['old_service_icon']){ unlink("assets/images/service/".$_POST['old_service_icon']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }
      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Master/service');
    }
    $service_info = $this->Master_Model->get_info_arr('service_id',$service_id,'service');
    if(!$service_info){ header('location:'.base_url().'Master/service'); }
    $data['update'] = 'update';
    $data['update_service'] = 'update';
    $data['service_info'] = $service_info[0];
    $data['act_link'] = base_url().'Master/edit_service/'.$service_id;

    $data['service_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','service_id','DESC','service');
    $data['page'] = 'Service';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/service', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Delete Service...
  public function delete_service($service_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $service_info = $this->Master_Model->get_info_arr_fields('service_image, service_icon, service_id', 'service_id', $service_id, 'service');
    if($service_info){
      $service_image = $service_info[0]['service_image'];
      if($service_image){ unlink("assets/images/service/".$service_image); }
      $service_icon = $service_info[0]['service_icon'];
      if($service_icon){ unlink("assets/images/service/".$service_icon); }
    }
    $this->Master_Model->delete_info('service_id', $service_id, 'service');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Master/service');
  }


/********************************* Treatment Speciality ***********************************/

  // Add Treatment Speciality...
  public function treat_speciality(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('treat_speciality_name', 'treat_speciality title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $treat_speciality_status = $this->input->post('treat_speciality_status');
      if(!isset($treat_speciality_status)){ $treat_speciality_status = '1'; }
      $save_data = $_POST;
      $save_data['treat_speciality_status'] = $treat_speciality_status;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['treat_speciality_addedby'] = $pharm_user_id;
      $treat_speciality_id = $this->Master_Model->save_data('treat_speciality', $save_data);

      if($_FILES['treat_speciality_image']['name']){
        $time = time();
        $image_name = 'treat_speciality_'.$treat_speciality_id.'_'.$time;
        $config['upload_path'] = 'assets/images/treat_speciality/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['treat_speciality_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('treat_speciality_image') && $treat_speciality_id && $image_name && $ext && $filename){
          $treat_speciality_image_up['treat_speciality_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('treat_speciality_id', $treat_speciality_id, 'treat_speciality', $treat_speciality_image_up);
          // unlink("assets/images/tours/".$treat_speciality_image_old);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      if($_FILES['treat_speciality_icon']['name']){
        $time = time();
        $image_name = 'treat_speciality_icon_'.$treat_speciality_id.'_'.$time;
        $config['upload_path'] = 'assets/images/treat_speciality/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['treat_speciality_icon']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('treat_speciality_icon') && $treat_speciality_id && $image_name && $ext && $filename){
          $treat_speciality_icon_up['treat_speciality_icon'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('treat_speciality_id', $treat_speciality_id, 'treat_speciality', $treat_speciality_icon_up);
          // unlink("assets/images/tours/".$treat_speciality_icon_old);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Master/treat_speciality');
    }
    $data['Page'] = 'Treatment Speciality';
    $data['treat_speciality_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','treat_speciality_id','DESC','treat_speciality');
    $data['page'] = 'Treatment Facility';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/treat_speciality', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit Treatment Speciality...
  public function edit_treat_speciality($treat_speciality_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('treat_speciality_name', 'treat_speciality title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $treat_speciality_status = $this->input->post('treat_speciality_status');
      if(!isset($treat_speciality_status)){ $treat_speciality_status = '1'; }
      $update_data = $_POST;
      unset($update_data['old_treat_speciality_img']);
      unset($update_data['old_treat_speciality_icon']);
      $update_data['treat_speciality_status'] = $treat_speciality_status;
      $update_data['treat_speciality_addedby'] = $pharm_user_id;
      $this->Master_Model->update_info('treat_speciality_id', $treat_speciality_id, 'treat_speciality', $update_data);

      if($_FILES['treat_speciality_image']['name']){
        $time = time();
        $image_name = 'treat_speciality_'.$treat_speciality_id.'_'.$time;
        $config['upload_path'] = 'assets/images/treat_speciality/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['treat_speciality_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('treat_speciality_image') && $treat_speciality_id && $image_name && $ext && $filename){
          $treat_speciality_image_up['treat_speciality_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('treat_speciality_id', $treat_speciality_id, 'treat_speciality', $treat_speciality_image_up);
          if($_POST['old_treat_speciality_img']){ unlink("assets/images/treat_speciality/".$_POST['old_treat_speciality_img']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      if($_FILES['treat_speciality_icon']['name']){
        $time = time();
        $image_name = 'treat_speciality_icon'.$treat_speciality_id.'_'.$time;
        $config['upload_path'] = 'assets/images/treat_speciality/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['treat_speciality_icon']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('treat_speciality_icon') && $treat_speciality_id && $image_name && $ext && $filename){
          $treat_speciality_icon_up['treat_speciality_icon'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('treat_speciality_id', $treat_speciality_id, 'treat_speciality', $treat_speciality_icon_up);
          if($_POST['old_treat_speciality_icon']){ unlink("assets/images/treat_speciality/".$_POST['old_treat_speciality_icon']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }
      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Master/treat_speciality');
    }
    $treat_speciality_info = $this->Master_Model->get_info_arr('treat_speciality_id',$treat_speciality_id,'treat_speciality');
    if(!$treat_speciality_info){ header('location:'.base_url().'Master/treat_speciality'); }
    $data['update'] = 'update';
    $data['update_treat_speciality'] = 'update';
    $data['treat_speciality_info'] = $treat_speciality_info[0];
    $data['act_link'] = base_url().'Master/edit_treat_speciality/'.$treat_speciality_id;

    $data['treat_speciality_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','treat_speciality_id','DESC','treat_speciality');
    $data['page'] = 'Treatment Facility';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/treat_speciality', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Delete Treatment Speciality...
  public function delete_treat_speciality($treat_speciality_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $treat_speciality_info = $this->Master_Model->get_info_arr_fields('treat_speciality_image, treat_speciality_icon, treat_speciality_id', 'treat_speciality_id', $treat_speciality_id, 'treat_speciality');
    if($treat_speciality_info){
      $treat_speciality_image = $treat_speciality_info[0]['treat_speciality_image'];
      if($treat_speciality_image){ unlink("assets/images/treat_speciality/".$treat_speciality_image); }
      $treat_speciality_icon = $treat_speciality_info[0]['treat_speciality_icon'];
      if($treat_speciality_icon){ unlink("assets/images/treat_speciality/".$treat_speciality_icon); }
    }
    $this->Master_Model->delete_info('treat_speciality_id', $treat_speciality_id, 'treat_speciality');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Master/treat_speciality');
  }



/********************************* Disease ***********************************/

  // Add Disease...
  public function disease(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('disease_name', 'disease title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $disease_status = $this->input->post('disease_status');
      if(!isset($disease_status)){ $disease_status = '1'; }
      $save_data = $_POST;
      $save_data['disease_status'] = $disease_status;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['disease_addedby'] = $pharm_user_id;
      $disease_id = $this->Master_Model->save_data('disease', $save_data);

      if($_FILES['disease_image']['name']){
        $time = time();
        $image_name = 'disease_'.$disease_id.'_'.$time;
        $config['upload_path'] = 'assets/images/disease/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['disease_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('disease_image') && $disease_id && $image_name && $ext && $filename){
          $disease_image_up['disease_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('disease_id', $disease_id, 'disease', $disease_image_up);
          // unlink("assets/images/tours/".$disease_image_old);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      if($_FILES['disease_icon']['name']){
        $time = time();
        $image_name = 'disease_icon_'.$disease_id.'_'.$time;
        $config['upload_path'] = 'assets/images/disease/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['disease_icon']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('disease_icon') && $disease_id && $image_name && $ext && $filename){
          $disease_icon_up['disease_icon'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('disease_id', $disease_id, 'disease', $disease_icon_up);
          // unlink("assets/images/tours/".$disease_icon_old);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Master/disease');
    }

    $data['disease_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','disease_id','DESC','disease');
    $data['page'] = 'Disease';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/disease', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit Disease...
  public function edit_disease($disease_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('disease_name', 'disease title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $disease_status = $this->input->post('disease_status');
      if(!isset($disease_status)){ $disease_status = '1'; }
      $update_data = $_POST;
      unset($update_data['old_disease_img']);
      unset($update_data['old_disease_icon']);
      $update_data['disease_status'] = $disease_status;
      $update_data['disease_addedby'] = $pharm_user_id;
      $this->Master_Model->update_info('disease_id', $disease_id, 'disease', $update_data);

      if($_FILES['disease_image']['name']){
        $time = time();
        $image_name = 'disease_'.$disease_id.'_'.$time;
        $config['upload_path'] = 'assets/images/disease/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['disease_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('disease_image') && $disease_id && $image_name && $ext && $filename){
          $disease_image_up['disease_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('disease_id', $disease_id, 'disease', $disease_image_up);
          if($_POST['old_disease_img']){ unlink("assets/images/disease/".$_POST['old_disease_img']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      if($_FILES['disease_icon']['name']){
        $time = time();
        $image_name = 'disease_icon'.$disease_id.'_'.$time;
        $config['upload_path'] = 'assets/images/disease/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['disease_icon']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('disease_icon') && $disease_id && $image_name && $ext && $filename){
          $disease_icon_up['disease_icon'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('disease_id', $disease_id, 'disease', $disease_icon_up);
          if($_POST['old_disease_icon']){ unlink("assets/images/disease/".$_POST['old_disease_icon']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }
      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Master/disease');
    }
    $disease_info = $this->Master_Model->get_info_arr('disease_id',$disease_id,'disease');
    if(!$disease_info){ header('location:'.base_url().'Master/disease'); }
    $data['update'] = 'update';
    $data['update_disease'] = 'update';
    $data['disease_info'] = $disease_info[0];
    $data['act_link'] = base_url().'Master/edit_disease/'.$disease_id;

    $data['disease_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','disease_id','DESC','disease');
    $data['page'] = 'Disease';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/disease', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Delete Disease...
  public function delete_disease($disease_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $disease_info = $this->Master_Model->get_info_arr_fields('disease_image, disease_icon, disease_id', 'disease_id', $disease_id, 'disease');
    if($disease_info){
      $disease_image = $disease_info[0]['disease_image'];
      if($disease_image){ unlink("assets/images/disease/".$disease_image); }
      $disease_icon = $disease_info[0]['disease_icon'];
      if($disease_icon){ unlink("assets/images/disease/".$disease_icon); }
    }
    $this->Master_Model->delete_info('disease_id', $disease_id, 'disease');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Master/disease');
  }


/********************************* Category ***********************************/

  // Add Category...
  public function category(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('category_name', 'category title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $category_status = $this->input->post('category_status');
      if(!isset($category_status)){ $category_status = '1'; }

      $save_data = $_POST;
      $save_data['category_status'] = $category_status;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['category_addedby'] = $pharm_user_id;

      $primary_category_id = $this->input->post('primary_category_id');
      if($primary_category_id == '-1'){
        $save_data['is_primary'] = 1;
        $save_data['primary_category_id'] = 0;
      } else{
        $save_data['is_primary'] = 0;
      }

      $category_id = $this->Master_Model->save_data('category', $save_data);

      if($_FILES['category_image']['name']){
        $time = time();
        $image_name = 'category_'.$category_id.'_'.$time;
        $config['upload_path'] = 'assets/images/category/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['category_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('category_image') && $category_id && $image_name && $ext && $filename){
          $category_image_up['category_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('category_id', $category_id, 'category', $category_image_up);
          // unlink("assets/images/tours/".$category_image_old);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      if($_FILES['category_icon']['name']){
        $time = time();
        $image_name = 'category_icon_'.$category_id.'_'.$time;
        $config['upload_path'] = 'assets/images/category/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['category_icon']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('category_icon') && $category_id && $image_name && $ext && $filename){
          $category_icon_up['category_icon'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('category_id', $category_id, 'category', $category_icon_up);
          // unlink("assets/images/tours/".$category_icon_old);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Master/category');
    }

    $data['category_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','category_id','DESC','category');
    $data['primary_category_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'is_primary','1','','','','','category_name','ASC','category');
    $data['page'] = 'Category';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/category', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit Category...
  public function edit_category($category_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('category_name', 'category title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $category_status = $this->input->post('category_status');
      if(!isset($category_status)){ $category_status = '1'; }
      $update_data = $_POST;
      unset($update_data['old_category_img']);
      unset($update_data['old_category_icon']);
      $update_data['category_status'] = $category_status;
      $update_data['category_addedby'] = $pharm_user_id;

      $primary_category_id = $this->input->post('primary_category_id');
      if($primary_category_id == '-1'){
        $update_data['is_primary'] = 1;
        $update_data['primary_category_id'] = 0;
      } else{
        $update_data['is_primary'] = 0;
      }

      $this->Master_Model->update_info('category_id', $category_id, 'category', $update_data);

      if($_FILES['category_image']['name']){
        $time = time();
        $image_name = 'category_'.$category_id.'_'.$time;
        $config['upload_path'] = 'assets/images/category/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['category_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('category_image') && $category_id && $image_name && $ext && $filename){
          $category_image_up['category_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('category_id', $category_id, 'category', $category_image_up);
          if($_POST['old_category_img']){ unlink("assets/images/category/".$_POST['old_category_img']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      if($_FILES['category_icon']['name']){
        $time = time();
        $image_name = 'category_icon'.$category_id.'_'.$time;
        $config['upload_path'] = 'assets/images/category/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['category_icon']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('category_icon') && $category_id && $image_name && $ext && $filename){
          $category_icon_up['category_icon'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('category_id', $category_id, 'category', $category_icon_up);
          if($_POST['old_category_icon']){ unlink("assets/images/category/".$_POST['old_category_icon']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }
      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Master/category');
    }
    $category_info = $this->Master_Model->get_info_arr('category_id',$category_id,'category');
    if(!$category_info){ header('location:'.base_url().'Master/category'); }
    $data['update'] = 'update';
    $data['update_category'] = 'update';
    $data['category_info'] = $category_info[0];
    $data['act_link'] = base_url().'Master/edit_category/'.$category_id;

    $data['category_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','category_id','DESC','category');
    $data['primary_category_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'is_primary','1','','','','','category_name','ASC','category');
    $data['page'] = 'Category';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/category', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Delete Category...
  public function delete_category($category_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $category_info = $this->Master_Model->get_info_arr_fields('category_image, category_icon, category_id', 'category_id', $category_id, 'category');
    if($category_info){
      $category_image = $category_info[0]['category_image'];
      if($category_image){ unlink("assets/images/category/".$category_image); }
      $category_icon = $category_info[0]['category_icon'];
      if($category_icon){ unlink("assets/images/category/".$category_icon); }
    }
    $this->Master_Model->delete_info('category_id', $category_id, 'category');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Master/category');
  }


/********************************* Group ***********************************/

  // Add Group...
  public function group(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('group_name', 'group title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $group_status = $this->input->post('group_status');
      if(!isset($group_status)){ $group_status = '1'; }

      $save_data = $_POST;
      $save_data['group_status'] = $group_status;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['group_addedby'] = $pharm_user_id;

      $primary_group_id = $this->input->post('primary_group_id');
      if($primary_group_id == '-1'){
        $save_data['is_primary'] = 1;
        $save_data['primary_group_id'] = 0;
      } else{
        $save_data['is_primary'] = 0;
      }

      $group_id = $this->Master_Model->save_data('group', $save_data);

      if($_FILES['group_image']['name']){
        $time = time();
        $image_name = 'group_'.$group_id.'_'.$time;
        $config['upload_path'] = 'assets/images/group/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['group_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('group_image') && $group_id && $image_name && $ext && $filename){
          $group_image_up['group_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('group_id', $group_id, 'group', $group_image_up);
          // unlink("assets/images/tours/".$group_image_old);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      if($_FILES['group_icon']['name']){
        $time = time();
        $image_name = 'group_icon_'.$group_id.'_'.$time;
        $config['upload_path'] = 'assets/images/group/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['group_icon']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('group_icon') && $group_id && $image_name && $ext && $filename){
          $group_icon_up['group_icon'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('group_id', $group_id, 'group', $group_icon_up);
          // unlink("assets/images/tours/".$group_icon_old);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Master/group');
    }

    $data['group_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','group_id','DESC','group');
    $data['primary_group_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'is_primary','1','','','','','group_name','ASC','group');
    $data['page'] = 'Group';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/group', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit Group...
  public function edit_group($group_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('group_name', 'group title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $group_status = $this->input->post('group_status');
      if(!isset($group_status)){ $group_status = '1'; }
      $update_data = $_POST;
      unset($update_data['old_group_img']);
      unset($update_data['old_group_icon']);
      $update_data['group_status'] = $group_status;
      $update_data['group_addedby'] = $pharm_user_id;

      $primary_group_id = $this->input->post('primary_group_id');
      if($primary_group_id == '-1'){
        $update_data['is_primary'] = 1;
        $update_data['primary_group_id'] = 0;
      } else{
        $update_data['is_primary'] = 0;
      }

      $this->Master_Model->update_info('group_id', $group_id, 'group', $update_data);

      if($_FILES['group_image']['name']){
        $time = time();
        $image_name = 'group_'.$group_id.'_'.$time;
        $config['upload_path'] = 'assets/images/group/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['group_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('group_image') && $group_id && $image_name && $ext && $filename){
          $group_image_up['group_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('group_id', $group_id, 'group', $group_image_up);
          if($_POST['old_group_img']){ unlink("assets/images/group/".$_POST['old_group_img']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      if($_FILES['group_icon']['name']){
        $time = time();
        $image_name = 'group_icon'.$group_id.'_'.$time;
        $config['upload_path'] = 'assets/images/group/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['group_icon']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('group_icon') && $group_id && $image_name && $ext && $filename){
          $group_icon_up['group_icon'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('group_id', $group_id, 'group', $group_icon_up);
          if($_POST['old_group_icon']){ unlink("assets/images/group/".$_POST['old_group_icon']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }
      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Master/group');
    }
    $group_info = $this->Master_Model->get_info_arr('group_id',$group_id,'group');
    if(!$group_info){ header('location:'.base_url().'Master/group'); }
    $data['update'] = 'update';
    $data['update_group'] = 'update';
    $data['group_info'] = $group_info[0];
    $data['act_link'] = base_url().'Master/edit_group/'.$group_id;

    $data['group_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','group_id','DESC','group');
    $data['primary_group_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'is_primary','1','','','','','group_name','ASC','group');
    $data['page'] = 'Group';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/group', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Delete Group...
  public function delete_group($group_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $group_info = $this->Master_Model->get_info_arr_fields('group_image, group_icon, group_id', 'group_id', $group_id, 'group');
    if($group_info){
      $group_image = $group_info[0]['group_image'];
      if($group_image){ unlink("assets/images/group/".$group_image); }
      $group_icon = $group_info[0]['group_icon'];
      if($group_icon){ unlink("assets/images/group/".$group_icon); }
    }
    $this->Master_Model->delete_info('group_id', $group_id, 'group');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Master/group');
  }


/************************************************** Only Design ************************************/
/************************************************** Only Design ************************************/
/************************************************** Only Design ************************************/
/************************************************** Only Design ************************************/
/************************************************** Only Design ************************************/



/********************************* GST Slab ***********************************/

  // Add GST Slab...
  public function gst_slab(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('gst_slab_name', 'gst_slab Name', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $gst_slab_status = $this->input->post('gst_slab_status');
      if(!isset($gst_slab_status)){ $gst_slab_status = '1'; }

      $calculate_on_mrp = $this->input->post('calculate_on_mrp');
      if(!isset($calculate_on_mrp)){ $calculate_on_mrp = '0'; }
      $calculate_on_goods = $this->input->post('calculate_on_goods');
      if(!isset($calculate_on_goods)){ $calculate_on_goods = '0'; }

      $save_data = $_POST;
      $save_data['gst_slab_status'] = $gst_slab_status;
      $save_data['calculate_on_mrp'] = $calculate_on_mrp;
      $save_data['calculate_on_goods'] = $calculate_on_goods;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['gst_slab_addedby'] = $pharm_user_id;
      $gst_slab_id = $this->Master_Model->save_data('gst_slab', $save_data);

      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Master/gst_slab');
    }

    $data['gst_slab_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','gst_slab_id','DESC','gst_slab');

    $data['Page'] = 'GST Slab';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/gst_slab', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit GST Slab...
  public function edit_gst_slab($gst_slab_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('gst_slab_name', 'gst_slab title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $gst_slab_status = $this->input->post('gst_slab_status');
      if(!isset($gst_slab_status)){ $gst_slab_status = '1'; }

      $calculate_on_mrp = $this->input->post('calculate_on_mrp');
      if(!isset($calculate_on_mrp)){ $calculate_on_mrp = '0'; }
      $calculate_on_goods = $this->input->post('calculate_on_goods');
      if(!isset($calculate_on_goods)){ $calculate_on_goods = '0'; }

      $update_data = $_POST;
      unset($update_data['old_gst_slab_img']);
      unset($update_data['old_gst_slab_icon']);
      $update_data['gst_slab_status'] = $gst_slab_status;
      $update_data['calculate_on_mrp'] = $calculate_on_mrp;
      $update_data['calculate_on_goods'] = $calculate_on_goods;
      $update_data['gst_slab_addedby'] = $pharm_user_id;
      $this->Master_Model->update_info('gst_slab_id', $gst_slab_id, 'gst_slab', $update_data);

      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Master/gst_slab');
    }
    $gst_slab_info = $this->Master_Model->get_info_arr('gst_slab_id',$gst_slab_id,'gst_slab');
    if(!$gst_slab_info){ header('location:'.base_url().'Master/gst_slab'); }
    $data['update'] = 'update';
    $data['update_gst_slab'] = 'update';
    $data['gst_slab_info'] = $gst_slab_info[0];
    $data['act_link'] = base_url().'Master/edit_gst_slab/'.$gst_slab_id;

    $data['gst_slab_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','gst_slab_id','DESC','gst_slab');
    // $data['primary_gst_slab_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'is_primary','1','','','','','gst_slab_name','ASC','gst_slab');
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/gst_slab', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Delete GST Slab...
  public function delete_gst_slab($gst_slab_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $this->Master_Model->delete_info('gst_slab_id', $gst_slab_id, 'gst_slab');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Master/gst_slab');
  }


/********************************* Bed Type ***********************************/

  // Add Bed Type...
  public function bed_type(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('bed_type_name', 'bed_type title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $bed_type_status = $this->input->post('bed_type_status');
      if(!isset($bed_type_status)){ $bed_type_status = '1'; }
      $save_data = $_POST;
      $save_data['bed_type_status'] = $bed_type_status;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['bed_type_addedby'] = $pharm_user_id;
      $bed_type_id = $this->Master_Model->save_data('bed_type', $save_data);

      if($_FILES['bed_type_image']['name']){
        $time = time();
        $image_name = 'bed_type_'.$bed_type_id.'_'.$time;
        $config['upload_path'] = 'assets/images/bed_type/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['bed_type_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('bed_type_image') && $bed_type_id && $image_name && $ext && $filename){
          $bed_type_image_up['bed_type_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('bed_type_id', $bed_type_id, 'bed_type', $bed_type_image_up);
          // unlink("assets/images/tours/".$bed_type_image_old);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }
      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Master/bed_type');
    }

    $data['bed_type_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','bed_type_id','DESC','bed_type');
    $data['page'] = 'Bed Type';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/bed_type', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit Bed Type...
  public function edit_bed_type($bed_type_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('bed_type_name', 'bed_type title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $bed_type_status = $this->input->post('bed_type_status');
      if(!isset($bed_type_status)){ $bed_type_status = '1'; }
      $update_data = $_POST;
      unset($update_data['old_bed_type_img']);
      $update_data['bed_type_status'] = $bed_type_status;
      $update_data['bed_type_addedby'] = $pharm_user_id;
      $this->Master_Model->update_info('bed_type_id', $bed_type_id, 'bed_type', $update_data);

      if($_FILES['bed_type_image']['name']){
        $time = time();
        $image_name = 'bed_type_'.$bed_type_id.'_'.$time;
        $config['upload_path'] = 'assets/images/bed_type/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['bed_type_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('bed_type_image') && $bed_type_id && $image_name && $ext && $filename){
          $bed_type_image_up['bed_type_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('bed_type_id', $bed_type_id, 'bed_type', $bed_type_image_up);
          if($_POST['old_bed_type_img']){ unlink("assets/images/bed_type/".$_POST['old_bed_type_img']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }
      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Master/bed_type');
    }
    $bed_type_info = $this->Master_Model->get_info_arr('bed_type_id',$bed_type_id,'bed_type');
    if(!$bed_type_info){ header('location:'.base_url().'Master/bed_type'); }
    $data['update'] = 'update';
    $data['update_bed_type'] = 'update';
    $data['bed_type_info'] = $bed_type_info[0];
    $data['act_link'] = base_url().'Master/edit_bed_type/'.$bed_type_id;

    $data['bed_type_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','bed_type_id','DESC','bed_type');
    $data['page'] = 'Bed Type';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/bed_type', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Delete Bed Type...
  public function delete_bed_type($bed_type_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $bed_type_info = $this->Master_Model->get_info_arr_fields('bed_type_image, bed_type_id', 'bed_type_id', $bed_type_id, 'bed_type');
    if($bed_type_info){
      $bed_type_image = $bed_type_info[0]['bed_type_image'];
      if($bed_type_image){ unlink("assets/images/bed_type/".$bed_type_image); }
    }
    $this->Master_Model->delete_info('bed_type_id', $bed_type_id, 'bed_type');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Master/bed_type');
  }


/********************************* Test Group ***********************************/

// Add Test Group...
public function test_group(){
  $pharm_user_id = $this->session->userdata('pharm_user_id');
  $pharm_company_id = $this->session->userdata('pharm_company_id');
  $pharm_role_id = $this->session->userdata('pharm_role_id');
  if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

  $this->form_validation->set_rules('test_group_name', 'test_group title', 'trim|required');
  if ($this->form_validation->run() != FALSE) {
    $test_group_status = $this->input->post('test_group_status');
    if(!isset($test_group_status)){ $test_group_status = '1'; }

    $save_data = $_POST;
    $save_data['test_group_status'] = $test_group_status;
    $save_data['company_id'] = $pharm_company_id;
    $save_data['test_group_addedby'] = $pharm_user_id;

    $primary_test_group_id = $this->input->post('primary_test_group_id');
    if($primary_test_group_id == '-1'){
      $save_data['is_primary'] = 1;
      $save_data['primary_test_group_id'] = 0;
    } else{
      $save_data['is_primary'] = 0;
    }

    $test_group_id = $this->Master_Model->save_data('test_group', $save_data);

    if($_FILES['test_group_image']['name']){
      $time = time();
      $image_name = 'test_group_'.$test_group_id.'_'.$time;
      $config['upload_path'] = 'assets/images/test_group/';
      $config['allowed_types'] = 'jpg|jpeg|png|gif';
      $config['file_name'] = $image_name;
      $filename = $_FILES['test_group_image']['name'];
      $ext = pathinfo($filename, PATHINFO_EXTENSION);
      $this->upload->initialize($config); // if upload library autoloaded
      if ($this->upload->do_upload('test_group_image') && $test_group_id && $image_name && $ext && $filename){
        $test_group_image_up['test_group_image'] =  $image_name.'.'.$ext;
        $this->Master_Model->update_info('test_group_id', $test_group_id, 'test_group', $test_group_image_up);
        // unlink("assets/images/tours/".$test_group_image_old);
        $this->session->set_flashdata('upload_success','File Uploaded Successfully');
      }
      else{
        $error = $this->upload->display_errors();
        $this->session->set_flashdata('upload_error',$error);
      }
    }

    if($_FILES['test_group_icon']['name']){
      $time = time();
      $image_name = 'test_group_icon_'.$test_group_id.'_'.$time;
      $config['upload_path'] = 'assets/images/test_group/';
      $config['allowed_types'] = 'jpg|jpeg|png|gif';
      $config['file_name'] = $image_name;
      $filename = $_FILES['test_group_icon']['name'];
      $ext = pathinfo($filename, PATHINFO_EXTENSION);
      $this->upload->initialize($config); // if upload library autoloaded
      if ($this->upload->do_upload('test_group_icon') && $test_group_id && $image_name && $ext && $filename){
        $test_group_icon_up['test_group_icon'] =  $image_name.'.'.$ext;
        $this->Master_Model->update_info('test_group_id', $test_group_id, 'test_group', $test_group_icon_up);
        // unlink("assets/images/tours/".$test_group_icon_old);
        $this->session->set_flashdata('upload_success','File Uploaded Successfully');
      }
      else{
        $error = $this->upload->display_errors();
        $this->session->set_flashdata('upload_error',$error);
      }
    }

    $this->session->set_flashdata('save_success','success');
    header('location:'.base_url().'Master/test_group');
  }

  $data['test_group_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','test_group_id','DESC','test_group');
  $data['primary_test_group_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'is_primary','1','','','','','test_group_name','ASC','test_group');
  $data['page'] = 'Test Group';
  $this->load->view('Admin/Include/head', $data);
  $this->load->view('Admin/Include/navbar', $data);
  $this->load->view('Admin/Master/test_group', $data);
  $this->load->view('Admin/Include/footer', $data);
}

// Edit Test Group...
public function edit_test_group($test_group_id){
  $pharm_user_id = $this->session->userdata('pharm_user_id');
  $pharm_company_id = $this->session->userdata('pharm_company_id');
  $pharm_role_id = $this->session->userdata('pharm_role_id');
  if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

  $this->form_validation->set_rules('test_group_name', 'test_group title', 'trim|required');
  if ($this->form_validation->run() != FALSE) {
    $test_group_status = $this->input->post('test_group_status');
    if(!isset($test_group_status)){ $test_group_status = '1'; }
    $update_data = $_POST;
    unset($update_data['old_test_group_img']);
    unset($update_data['old_test_group_icon']);
    $update_data['test_group_status'] = $test_group_status;
    $update_data['test_group_addedby'] = $pharm_user_id;

    $primary_test_group_id = $this->input->post('primary_test_group_id');
    if($primary_test_group_id == '-1'){
      $update_data['is_primary'] = 1;
      $update_data['primary_test_group_id'] = 0;
    } else{
      $update_data['is_primary'] = 0;
    }

    $this->Master_Model->update_info('test_group_id', $test_group_id, 'test_group', $update_data);

    if($_FILES['test_group_image']['name']){
      $time = time();
      $image_name = 'test_group_'.$test_group_id.'_'.$time;
      $config['upload_path'] = 'assets/images/test_group/';
      $config['allowed_types'] = 'jpg|jpeg|png|gif';
      $config['file_name'] = $image_name;
      $filename = $_FILES['test_group_image']['name'];
      $ext = pathinfo($filename, PATHINFO_EXTENSION);
      $this->upload->initialize($config); // if upload library autoloaded
      if ($this->upload->do_upload('test_group_image') && $test_group_id && $image_name && $ext && $filename){
        $test_group_image_up['test_group_image'] =  $image_name.'.'.$ext;
        $this->Master_Model->update_info('test_group_id', $test_group_id, 'test_group', $test_group_image_up);
        if($_POST['old_test_group_img']){ unlink("assets/images/test_group/".$_POST['old_test_group_img']); }
        $this->session->set_flashdata('upload_success','File Uploaded Successfully');
      }
      else{
        $error = $this->upload->display_errors();
        $this->session->set_flashdata('upload_error',$error);
      }
    }

    if($_FILES['test_group_icon']['name']){
      $time = time();
      $image_name = 'test_group_icon'.$test_group_id.'_'.$time;
      $config['upload_path'] = 'assets/images/test_group/';
      $config['allowed_types'] = 'jpg|jpeg|png|gif';
      $config['file_name'] = $image_name;
      $filename = $_FILES['test_group_icon']['name'];
      $ext = pathinfo($filename, PATHINFO_EXTENSION);
      $this->upload->initialize($config); // if upload library autoloaded
      if ($this->upload->do_upload('test_group_icon') && $test_group_id && $image_name && $ext && $filename){
        $test_group_icon_up['test_group_icon'] =  $image_name.'.'.$ext;
        $this->Master_Model->update_info('test_group_id', $test_group_id, 'test_group', $test_group_icon_up);
        if($_POST['old_test_group_icon']){ unlink("assets/images/test_group/".$_POST['old_test_group_icon']); }
        $this->session->set_flashdata('upload_success','File Uploaded Successfully');
      }
      else{
        $error = $this->upload->display_errors();
        $this->session->set_flashdata('upload_error',$error);
      }
    }
    $this->session->set_flashdata('update_success','success');
    header('location:'.base_url().'Master/test_group');
  }
  $test_group_info = $this->Master_Model->get_info_arr('test_group_id',$test_group_id,'test_group');
  if(!$test_group_info){ header('location:'.base_url().'Master/test_group'); }
  $data['update'] = 'update';
  $data['update_test_group'] = 'update';
  $data['test_group_info'] = $test_group_info[0];
  $data['act_link'] = base_url().'Master/edit_test_group/'.$test_group_id;

  $data['test_group_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','test_group_id','DESC','test_group');
  $data['primary_test_group_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'is_primary','1','','','','','test_group_name','ASC','test_group');
  $data['page'] = 'Test Group';
  $this->load->view('Admin/Include/head', $data);
  $this->load->view('Admin/Include/navbar', $data);
  $this->load->view('Admin/Master/test_group', $data);
  $this->load->view('Admin/Include/footer', $data);
}

// Delete Test Group...
public function delete_test_group($test_group_id){
  $pharm_user_id = $this->session->userdata('pharm_user_id');
  $pharm_company_id = $this->session->userdata('pharm_company_id');
  $pharm_role_id = $this->session->userdata('pharm_role_id');
  if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }
  $test_group_info = $this->Master_Model->get_info_arr_fields('test_group_image, test_group_id, test_group_icon', 'test_group_id', $test_group_id, 'test_group');
  if($test_group_info){
    $test_group_image = $test_group_info[0]['test_group_image'];
    if($test_group_image){ unlink("assets/images/test_group/".$test_group_image); }
    $test_group_icon = $test_group_info[0]['test_group_icon'];
    if($test_group_icon){ unlink("assets/images/test_group/".$test_group_icon); }
  }
  $this->Master_Model->delete_info('test_group_id', $test_group_id, 'test_group');
  $this->session->set_flashdata('delete_success','success');
  header('location:'.base_url().'Master/test_group');
}



/********************************* Test ***********************************/

  // Add Test...
  public function test(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('test_name', 'test title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $test_status = $this->input->post('test_status');
      if(!isset($test_status)){ $test_status = '1'; }
      $test_is_widal = $this->input->post('test_is_widal');
      if(!isset($test_is_widal)){ $test_is_widal = '0'; }

      $save_data = $_POST;
      $save_data['test_status'] = $test_status;
      $save_data['test_is_widal'] = $test_is_widal;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['test_addedby'] = $pharm_user_id;

      $test_id = $this->Master_Model->save_data('test', $save_data);

      if($_FILES['test_image']['name']){
        $time = time();
        $image_name = 'test_'.$test_id.'_'.$time;
        $config['upload_path'] = 'assets/images/test/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['test_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('test_image') && $test_id && $image_name && $ext && $filename){
          $test_image_up['test_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('test_id', $test_id, 'test', $test_image_up);
          // unlink("assets/images/tours/".$test_image_old);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      if($_FILES['test_icon']['name']){
        $time = time();
        $image_name = 'test_icon_'.$test_id.'_'.$time;
        $config['upload_path'] = 'assets/images/test/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['test_icon']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('test_icon') && $test_id && $image_name && $ext && $filename){
          $test_icon_up['test_icon'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('test_id', $test_id, 'test', $test_icon_up);
          // unlink("assets/images/tours/".$test_icon_old);
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Master/test');
    }


    $data['test_group_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'is_primary','1','test_group_status','1','','','test_group_name','ASC','test_group');
    $data['unit_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'unit_status','1','','','','','unit_name','ASC','unit');
    $data['test_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','test_id','DESC','test');
    $data['page'] = 'Test';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/test', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit Test...
  public function edit_test($test_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('test_name', 'test title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $test_status = $this->input->post('test_status');
      if(!isset($test_status)){ $test_status = '1'; }
      $test_is_widal = $this->input->post('test_is_widal');
      if(!isset($test_is_widal)){ $test_is_widal = '0'; }

      $update_data = $_POST;
      unset($update_data['old_test_img']);
      unset($update_data['old_test_icon']);
      $update_data['test_status'] = $test_status;
      $update_data['test_is_widal'] = $test_is_widal;
      $update_data['test_addedby'] = $pharm_user_id;

      $this->Master_Model->update_info('test_id', $test_id, 'test', $update_data);

      if($_FILES['test_image']['name']){
        $time = time();
        $image_name = 'test_'.$test_id.'_'.$time;
        $config['upload_path'] = 'assets/images/test/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['test_image']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('test_image') && $test_id && $image_name && $ext && $filename){
          $test_image_up['test_image'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('test_id', $test_id, 'test', $test_image_up);
          if($_POST['old_test_img']){ unlink("assets/images/test/".$_POST['old_test_img']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }

      if($_FILES['test_icon']['name']){
        $time = time();
        $image_name = 'test_icon'.$test_id.'_'.$time;
        $config['upload_path'] = 'assets/images/test/';
        $config['allowed_types'] = 'jpg|jpeg|png|gif';
        $config['file_name'] = $image_name;
        $filename = $_FILES['test_icon']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $this->upload->initialize($config); // if upload library autoloaded
        if ($this->upload->do_upload('test_icon') && $test_id && $image_name && $ext && $filename){
          $test_icon_up['test_icon'] =  $image_name.'.'.$ext;
          $this->Master_Model->update_info('test_id', $test_id, 'test', $test_icon_up);
          if($_POST['old_test_icon']){ unlink("assets/images/test/".$_POST['old_test_icon']); }
          $this->session->set_flashdata('upload_success','File Uploaded Successfully');
        }
        else{
          $error = $this->upload->display_errors();
          $this->session->set_flashdata('upload_error',$error);
        }
      }
      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Master/test');
    }
    $test_info = $this->Master_Model->get_info_arr('test_id',$test_id,'test');
    if(!$test_info){ header('location:'.base_url().'Master/test'); }
    $data['update'] = 'update';
    $data['update_test'] = 'update';
    $data['test_info'] = $test_info[0];
    $data['act_link'] = base_url().'Master/edit_test/'.$test_id;
    $primary_test_group_id = $test_info[0]['test_group_id'];
    $data['test_group_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'is_primary','1','test_group_status','1','','','test_group_name','ASC','test_group');
    $data['test_subgroup_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'is_primary','0','test_group_status','1','primary_test_group_id',$primary_test_group_id,'test_group_name','ASC','test_group');
    $data['unit_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'unit_status','1','','','','','unit_name','ASC','unit');
    $data['test_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','test_id','DESC','test');
    $data['page'] = 'Test';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Master/test', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Delete Test...
  public function delete_test($test_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $test_info = $this->Master_Model->get_info_arr_fields('test_image, test_icon, test_id', 'test_id', $test_id, 'test');
    if($test_info){
      $test_image = $test_info[0]['test_image'];
      if($test_image){ unlink("assets/images/test/".$test_image); }
      $test_icon = $test_info[0]['test_icon'];
      if($test_icon){ unlink("assets/images/test/".$test_icon); }
    }
    $this->Master_Model->delete_info('test_id', $test_id, 'test');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Master/test');
  }









/*************************************** Old Code ************************************/
/*************************************** Old Code ************************************/
/*************************************** Old Code ************************************/
/*************************************** Old Code ************************************/
/*************************************** Old Code ************************************/
/*************************************** Old Code ************************************/
/*************************************** Old Code ************************************/
/*************************************** Old Code ************************************/
/*************************************** Old Code ************************************/



/*****************************************************************************************/
  // Check Duplication
  public function check_duplication(){
    $column_name = $this->input->post('column_name');
    $column_val = $this->input->post('column_val');
    $table_name = $this->input->post('table_name');
    $company_id = '';
    $cnt = $this->Master_Model->check_duplication($company_id,$column_val,$column_name,$table_name);
    echo $cnt;
  }

  // get_sub_testgroup_by_main
  public function get_sub_testgroup_by_main(){
    $test_group_id = $this->input->post('test_group_id');
    $test_subgroup_list = $this->Master_Model->get_list_by_id3('','primary_test_group_id',$test_group_id,'test_group_status','1','','','test_group_name','ASC','test_group');
    echo "<option value='' selected >Select Test SubGroup</option>";
    foreach ($test_subgroup_list as $list) {
      echo "<option value='".$list->test_group_id."'> ".$list->test_group_name." </option>";
    }
  }

  // get_city_by_state
  public function get_city_by_state(){
    $state_id = $this->input->post('state_id');
    $city_list = $this->Master_Model->get_list_by_id3('','state_id',$state_id,'','','','','city_name','ASC','city');
    echo "<option value='' selected >Select City</option>";
    foreach ($city_list as $list) {
      echo "<option value='".$list->city_id."'> ".$list->city_name." </option>";
    }
  }

}
?>
