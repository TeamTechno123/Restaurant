<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hospital extends CI_Controller{
  public function __construct(){
    parent::__construct();
    date_default_timezone_set('Asia/Kolkata');
  }

  /*********************************** Hospital *********************************/

    // Add Hospital....
    public function hospital(){
      $pharm_user_id = $this->session->userdata('pharm_user_id');
      $pharm_company_id = $this->session->userdata('pharm_company_id');
      $pharm_role_id = $this->session->userdata('pharm_role_id');
      if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

      $this->form_validation->set_rules('hospital_name', 'Batch Name', 'trim|required');
      if ($this->form_validation->run() != FALSE) {
        $hospital_status = $this->input->post('hospital_status');
        if(!isset($hospital_status)){ $hospital_status = '1'; }
        $save_data = $_POST;
        unset($save_data['hospital_password']);
        $hospital_facility = implode(", ", $_POST['hospital_facility']);
        $hospital_accrediation = implode(", ", $_POST['hospital_accrediation']);
        $hospital_pay_mode = implode(", ", $_POST['hospital_pay_mode']);
        $save_data['hospital_facility'] = $hospital_facility;
        $save_data['hospital_accrediation'] = $hospital_accrediation;
        $save_data['hospital_pay_mode'] = $hospital_pay_mode;
        $save_data['hospital_status'] = $hospital_status;
        $save_data['company_id'] = $pharm_company_id;
        $save_data['hospital_addedby'] = $pharm_user_id;
        $hospital_id = $this->Master_Model->save_data('hospital', $save_data);

        // Save User...
        $save_user_data['hospital_id'] = $hospital_id;
        $save_user_data['company_id'] = $pharm_company_id;
        $save_user_data['hospital_role_id'] = 1;
        $save_user_data['is_hospital_admin'] = 1;
        $save_user_data['hospital_user_name'] = 'Hospital Admin';
        $save_user_data['hospital_user_mobile'] = $_POST['hospital_mobile'];
        $save_user_data['hospital_user_password'] = $_POST['hospital_password'];
        $save_user_data['hospital_user_email'] = $_POST['hospital_email'];
        $save_user_data['country_id'] = '101';
        $save_user_data['hospital_role_id'] = 1;
        $save_user_data['hospital_user_addedby'] = 'Admin';
        $hospital_user_id = $this->Master_Model->save_data('hospital_user', $save_user_data);

        if($_FILES['hospital_image']['name']){
          $time = time();
          $image_name = 'hospital_'.$hospital_id.'_'.$time;
          $config['upload_path'] = 'assets/images/hospital/';
          $config['allowed_types'] = 'jpg|jpeg|png|gif';
          $config['file_name'] = $image_name;
          $filename = $_FILES['hospital_image']['name'];
          $ext = pathinfo($filename, PATHINFO_EXTENSION);
          $this->upload->initialize($config); // if upload library autoloaded
          if ($this->upload->do_upload('hospital_image') && $hospital_id && $image_name && $ext && $filename){
            $hospital_image_up['hospital_image'] =  $image_name.'.'.$ext;
            $this->Master_Model->update_info('hospital_id', $hospital_id, 'hospital', $hospital_image_up);
            $this->session->set_flashdata('upload_success','File Uploaded Successfully');
          }
          else{
            $error = $this->upload->display_errors();
            $this->session->set_flashdata('upload_error',$error);
          }
        }
        $this->session->set_flashdata('save_success','success');
        header('location:'.base_url().'Hospital/hospital');
      }
      $data['hospital_type_list'] = $this->Master_Model->get_list_by_id3('','','','','','','','hospital_type_id','ASC','hospital_type');
      $data['state_list'] = $this->Master_Model->get_list_by_id3('','country_id','101','','','','','state_name','ASC','state');
      $data['facility_list'] = $this->Master_Model->get_list_by_id3('','facility_status','1','','','','','facility_name','ASC','facility');
      $data['payment_mode_list'] = $this->Master_Model->get_list_by_id3('','payment_mode_status','1','','','','','payment_mode_name','ASC','payment_mode');

      $hospital_type_id = $this->uri->segment(3);
      if($hospital_type_id){
        $data['hospital_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'hospital_type',$hospital_type_id,'','','','','hospital_id','DESC','hospital');
      } else{
        $data['hospital_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','hospital_id','DESC','hospital');
      }

      $data['page'] = 'Hospital';
      $this->load->view('Admin/Include/head', $data);
      $this->load->view('Admin/Include/navbar', $data);
      $this->load->view('Admin/Hospital/hospital', $data);
      $this->load->view('Admin/Include/footer', $data);
    }

    // Edit/Update Hospital...
    public function edit_hospital($hospital_id){
      $pharm_user_id = $this->session->userdata('pharm_user_id');
      $pharm_company_id = $this->session->userdata('pharm_company_id');
      $pharm_role_id = $this->session->userdata('pharm_role_id');
      if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

      $this->form_validation->set_rules('hospital_name', 'First Name', 'trim|required');
      if ($this->form_validation->run() != FALSE) {
        $hospital_status = $this->input->post('hospital_status');
        if(!isset($hospital_status)){ $hospital_status = '1'; }
        $update_data = $_POST;
        $hospital_facility = implode(", ", $_POST['hospital_facility']);
        $hospital_accrediation = implode(", ", $_POST['hospital_accrediation']);
        $hospital_pay_mode = implode(", ", $_POST['hospital_pay_mode']);

        $update_data['hospital_facility'] = $hospital_facility;
        $update_data['hospital_accrediation'] = $hospital_accrediation;
        $update_data['hospital_pay_mode'] = $hospital_pay_mode;

        unset($update_data['old_hospital_img']);
        $update_data['hospital_status'] = $hospital_status;
        $update_data['hospital_addedby'] = $pharm_user_id;
        $this->Master_Model->update_info('hospital_id', $hospital_id, 'hospital', $update_data);

        if($_FILES['hospital_image']['name']){
          $time = time();
          $image_name = 'hospital_'.$hospital_id.'_'.$time;
          $config['upload_path'] = 'assets/images/hospital/';
          $config['allowed_types'] = 'jpg|jpeg|png|gif';
          $config['file_name'] = $image_name;
          $filename = $_FILES['hospital_image']['name'];
          $ext = pathinfo($filename, PATHINFO_EXTENSION);
          $this->upload->initialize($config); // if upload library autoloaded
          if ($this->upload->do_upload('hospital_image') && $hospital_id && $image_name && $ext && $filename){
            $hospital_image_up['hospital_image'] =  $image_name.'.'.$ext;
            $this->Master_Model->update_info('hospital_id', $hospital_id, 'hospital', $hospital_image_up);
            if($_POST['old_hospital_img']){ unlink("assets/images/hospital/".$_POST['old_hospital_img']); }
            $this->session->set_flashdata('upload_success','File Uploaded Successfully');
          }
          else{
            $error = $this->upload->display_errors();
            $this->session->set_flashdata('upload_error',$error);
          }
        }

        $this->session->set_flashdata('update_success','success');
        header('location:'.base_url().'Hospital/hospital');
      }

      $hospital_info = $this->Master_Model->get_info_arr('hospital_id',$hospital_id,'hospital');
      if(!$hospital_info){ header('location:'.base_url().'Hospital/hospital'); }
      $data['update'] = 'update';
      $data['update_hospital'] = 'update';
      $data['hospital_info'] = $hospital_info[0];
      $data['act_link'] = base_url().'Hospital/edit_hospital/'.$hospital_id;
      $state_id = $hospital_info[0]['state_id'];

      $data['hospital_type_list'] = $this->Master_Model->get_list_by_id3('','','','','','','','hospital_type_id','ASC','hospital_type');
      $data['state_list'] = $this->Master_Model->get_list_by_id3('','country_id','101','','','','','state_name','ASC','state');
      $data['city_list'] = $this->Master_Model->get_list_by_id3('','state_id',$state_id,'','','','','city_name','ASC','city');
      $data['facility_list'] = $this->Master_Model->get_list_by_id3('','facility_status','1','','','','','facility_name','ASC','facility');
      $data['payment_mode_list'] = $this->Master_Model->get_list_by_id3('','payment_mode_status','1','','','','','payment_mode_name','ASC','payment_mode');

      $data['hospital_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','hospital_id','DESC','hospital');
      $this->load->view('Admin/Include/head', $data);
      $this->load->view('Admin/Include/navbar', $data);
      $this->load->view('Admin/Hospital/hospital', $data);
      $this->load->view('Admin/Include/footer', $data);
    }

    //Delete Hospital...
    public function delete_hospital($hospital_id){
      $pharm_user_id = $this->session->userdata('pharm_user_id');
      $pharm_company_id = $this->session->userdata('pharm_company_id');
      $pharm_role_id = $this->session->userdata('pharm_role_id');
      if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }
      $hospital_info = $this->Master_Model->get_info_arr_fields('hospital_image, hospital_id', 'hospital_id', $hospital_id, 'hospital');
      if($hospital_info){
        $hospital_image = $hospital_info[0]['hospital_image'];
        if($hospital_image){ unlink("assets/images/hospital/".$hospital_image); }
      }
      $this->Master_Model->delete_info('hospital_id', $hospital_id, 'hospital');
      $this->session->set_flashdata('delete_success','success');
      header('location:'.base_url().'Hospital/hospital');
    }

/********************************************* Package ***********************************************/
  public function cov_package_sess($hospital_id){
    $this->session->set_userdata('hospital_id',$hospital_id);
    header('location:'.base_url().'Hospital/cov_package');
  }

  // Add Package...
  public function cov_package(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    $hospital_id = $this->session->userdata('hospital_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $hospital_info = $this->Master_Model->get_info_arr('hospital_id',$hospital_id,'hospital');
    if(!$hospital_info){ header('location:'.base_url().'Hospital/hospital'); }

    $this->form_validation->set_rules('cov_package_name', 'cov_package title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $cov_package_status = $this->input->post('cov_package_status');
      if(!isset($cov_package_status)){ $cov_package_status = '1'; }
      $save_data = $_POST;
      $save_data['cov_package_status'] = $cov_package_status;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['hospital_id'] = $hospital_id;
      $save_data['cov_package_addedby_user'] = $pharm_user_id;
      $cov_package_id = $this->Master_Model->save_data('cov_package', $save_data);

      if(isset($_FILES['cov_package_file_name']['name'])){
        $this->load->library('upload');
        $files = $_FILES;
        $cpt = count($_FILES['cov_package_file_name']['name']);
        for($i=0; $i<$cpt; $i++)
        {
          $j = $i+1;
          $time = time();
          $image_name = 'cov_package_'.$hospital_id.'_'.$cov_package_id.'_'.$time;
            $_FILES['cov_package_file_name']['name']= $files['cov_package_file_name']['name'][$i];
            $_FILES['cov_package_file_name']['type']= $files['cov_package_file_name']['type'][$i];
            $_FILES['cov_package_file_name']['tmp_name']= $files['cov_package_file_name']['tmp_name'][$i];
            $_FILES['cov_package_file_name']['error']= $files['cov_package_file_name']['error'][$i];
            $_FILES['cov_package_file_name']['size']= $files['cov_package_file_name']['size'][$i];
            $config['upload_path'] = 'assets/images/cov_package/';
            $config['allowed_types'] = 'gif|jpg|png|pdf|docx|ppt';
            $config['file_name'] = $image_name;
            $config['overwrite']     = FALSE;
            $filename = $files['cov_package_file_name']['name'][$i];
            $ext = pathinfo($filename, PATHINFO_EXTENSION);
            $this->upload->initialize($config);
            if($this->upload->do_upload('cov_package_file_name')){
              $file_data['cov_package_file_name'] = $image_name.'.'.$ext;
              $file_data['cov_package_id'] = $cov_package_id;
              $this->Master_Model->save_data('cov_package_file', $file_data);
            }
            else{
              $error = $this->upload->display_errors();
              $this->session->set_flashdata('status',$this->upload->display_errors());
            }
        }
      }

      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Hospital/cov_package');
    }

    $hospital_info = $this->Master_Model->get_info_arr('hospital_id',$hospital_id,'hospital');
    if(!$hospital_info){ header('location:'.base_url().'Hospital/hospital'); }
    // $data['update'] = 'update';
    // $data['update_cov_package'] = 'update';
    $data['hospital_info'] = $hospital_info[0];
    $data['act_link'] = base_url().'Hospital/cov_package';
    $data['hospital_type_list'] = $this->Master_Model->get_list_by_id3('','','','','','','','hospital_type_id','ASC','hospital_type');

    $data['cov_package_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'hospital_id',$hospital_id,'','','','','cov_package_id','DESC','cov_package');
    $data['page'] = 'Package';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Hospital/cov_package', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit Package...
  public function edit_cov_package($cov_package_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    $hospital_id = $this->session->userdata('hospital_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $hospital_info = $this->Master_Model->get_info_arr('hospital_id',$hospital_id,'hospital');
    if(!$hospital_info){ header('location:'.base_url().'Hospital/hospital'); }

    $this->form_validation->set_rules('cov_package_name', 'cov_package title', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $cov_package_status = $this->input->post('cov_package_status');
      if(!isset($cov_package_status)){ $cov_package_status = '1'; }
      $update_data = $_POST;
      unset($update_data['input']);
      $update_data['cov_package_status'] = $cov_package_status;
      $update_data['cov_package_addedby_user'] = $pharm_user_id;
      $this->Master_Model->update_info('cov_package_id', $cov_package_id, 'cov_package', $update_data);

      if(isset($_FILES['cov_package_file_name']['name'])){
        $this->load->library('upload');
        $files = $_FILES;
        $cpt = count($_FILES['cov_package_file_name']['name']);
        for($i=0; $i<$cpt; $i++)
        {
          $j = $i+1;
          $time = time();
          $image_name = 'cov_package_'.$hospital_id.'_'.$cov_package_id.'_'.$time;
            $_FILES['cov_package_file_name']['name']= $files['cov_package_file_name']['name'][$i];
            $_FILES['cov_package_file_name']['type']= $files['cov_package_file_name']['type'][$i];
            $_FILES['cov_package_file_name']['tmp_name']= $files['cov_package_file_name']['tmp_name'][$i];
            $_FILES['cov_package_file_name']['error']= $files['cov_package_file_name']['error'][$i];
            $_FILES['cov_package_file_name']['size']= $files['cov_package_file_name']['size'][$i];
            $config['upload_path'] = 'assets/images/cov_package/';
            $config['allowed_types'] = 'gif|jpg|png|pdf|docx|ppt';
            $config['file_name'] = $image_name;
            $config['overwrite']     = FALSE;
            $filename = $files['cov_package_file_name']['name'][$i];
            $ext = pathinfo($filename, PATHINFO_EXTENSION);
            $this->upload->initialize($config);
            if($this->upload->do_upload('cov_package_file_name')){
              $file_data['cov_package_file_name'] = $image_name.'.'.$ext;
              $file_data['cov_package_id'] = $cov_package_id;
              $this->Master_Model->save_data('cov_package_file', $file_data);
            }
            else{
              $error = $this->upload->display_errors();
              $this->session->set_flashdata('status',$this->upload->display_errors());
            }
        }
      }

      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Hospital/cov_package');
    }

    $hospital_info = $this->Master_Model->get_info_arr('hospital_id',$hospital_id,'hospital');
    if(!$hospital_info){ header('location:'.base_url().'Hospital/hospital'); }

    $cov_package_info = $this->Master_Model->get_info_arr('cov_package_id',$cov_package_id,'cov_package');
    if(!$cov_package_info){ header('location:'.base_url().'Hospital/cov_package'); }

    $data['update'] = 'update';
    // $data['update_cov_package'] = 'update';
    $data['hospital_info'] = $hospital_info[0];
    $data['cov_package_info'] = $cov_package_info[0];
    $data['act_link'] = base_url().'Hospital/edit_cov_package'.$cov_package_id;
    $data['hospital_type_list'] = $this->Master_Model->get_list_by_id3('','','','','','','','hospital_type_id','ASC','hospital_type');
    $data['cov_package_file_list'] = $this->Master_Model->get_list_by_id3('','cov_package_id',$cov_package_id,'','','','','cov_package_file_id','ASC','cov_package_file');

    $data['cov_package_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'hospital_id',$hospital_id,'','','','','cov_package_id','DESC','cov_package');
    $data['page'] = 'Package';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Hospital/cov_package', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Delete Package...
  public function delete_cov_package($cov_package_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' && $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    // $cov_package_info = $this->Master_Model->get_info_arr_fields('cov_package_image, cov_package_id', 'cov_package_id', $cov_package_id, 'cov_package');
    // if($cov_package_info){
    //   $cov_package_image = $cov_package_info[0]['cov_package_image'];
    //   if($cov_package_image){ unlink("assets/images/cov_package/".$cov_package_image); }
    // }
    $this->Master_Model->delete_info('cov_package_id', $cov_package_id, 'cov_package');
    $this->Master_Model->delete_info('cov_package_id', $cov_package_id, 'cov_package_file');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Hospital/cov_package');
  }

  // Delete Package File
  public function delete_cov_package_file(){
    $cov_package_file_id = $this->input->post('cov_package_file_id');
    $cov_package_info = $this->Master_Model->get_info_arr_fields('cov_package_file_name, cov_package_file_id', 'cov_package_file_id', $cov_package_file_id, 'cov_package_file');
    if($cov_package_info){
      $cov_package_file_name = $cov_package_info[0]['cov_package_file_name'];
      if($cov_package_file_name){ unlink("assets/images/cov_package/".$cov_package_file_name); }
    }
    $this->Master_Model->delete_info('cov_package_file_id', $cov_package_file_id, 'cov_package_file');
  }


/********************************* COVID Treatment ***********************************/
  // Add COVID Treatment...
  public function cov_treatment(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' || $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('cov_treatment_name', 'COVID Treatment Name', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $cov_treatment_status = $this->input->post('cov_treatment_status');
      if(!isset($cov_treatment_status)){ $cov_treatment_status = '1'; }
      $save_data = $_POST;
      $save_data['cov_treatment_status'] = $cov_treatment_status;
      $save_data['company_id'] = $pharm_company_id;
      $save_data['cov_treatment_addedby'] = $pharm_user_id;
      $user_id = $this->Master_Model->save_data('cov_treatment', $save_data);

      $this->session->set_flashdata('save_success','success');
      header('location:'.base_url().'Hospital/cov_treatment');
    }

    $data['cov_treatment_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','cov_treatment_id','ASC','cov_treatment');
    $data['page'] = 'COVID Treatment';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Hospital/cov_treatment', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  // Edit/Update COVID Treatment...
  public function edit_cov_treatment($cov_treatment_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' || $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('cov_treatment_name', 'COVID Treatment Name', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $cov_treatment_status = $this->input->post('cov_treatment_status');
      if(!isset($cov_treatment_status)){ $cov_treatment_status = '1'; }
      $update_data = $_POST;
      $update_data['cov_treatment_status'] = $cov_treatment_status;
      $update_data['cov_treatment_addedby'] = $pharm_user_id;
      $this->Master_Model->update_info('cov_treatment_id', $cov_treatment_id, 'cov_treatment', $update_data);

      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Hospital/cov_treatment');
    }

    $cov_treatment_info = $this->Master_Model->get_info_arr('cov_treatment_id',$cov_treatment_id,'cov_treatment');
    if(!$cov_treatment_info){ header('location:'.base_url().'Hospital/cov_treatment'); }
    $data['update'] = 'update';
    $data['update_cov_treatment'] = 'update';
    $data['cov_treatment_info'] = $cov_treatment_info[0];
    $data['act_link'] = base_url().'Hospital/edit_cov_treatment/'.$cov_treatment_id;

    $data['cov_treatment_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'','','','','','','cov_treatment_id','ASC','cov_treatment');
    $data['page'] = 'COVID Treatment';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Hospital/cov_treatment', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

  //Delete COVID Treatment...
  public function delete_cov_treatment($cov_treatment_id){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' || $pharm_company_id == ''){ header('location:'.base_url().'User'); }
    $this->Master_Model->delete_info('cov_treatment_id', $cov_treatment_id, 'cov_treatment');
    $this->session->set_flashdata('delete_success','success');
    header('location:'.base_url().'Hospital/cov_treatment');
  }



/****************************************** Available Bed ****************************************/
  // Edit/Update Available Bed Count...
  public function available_bed(){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' || $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $this->form_validation->set_rules('hospital_id', 'Hospital Name', 'trim|required');
    if ($this->form_validation->run() != FALSE) {
      $hospital_id = $_POST['hospital_id'];
      $update_data = $_POST;
      unset($update_data['hospital_id']);
      $this->Master_Model->update_info('hospital_id', $hospital_id, 'hospital', $update_data);

      $this->session->set_flashdata('update_success','success');
      header('location:'.base_url().'Hospital/available_bed');
    }
    $data['update'] = 'update';
    $data['update_available_bed'] = 'update';
    $data['act_link'] = base_url().'Hospital/available_bed';

    $data['hospital_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id,'hospital_type !=','4','hospital_status','1','','','hospital_name','ASC','hospital');
    $data['page'] = 'Available Bed';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Hospital/available_bed', $data);
    $this->load->view('Admin/Include/footer', $data);
  }

/************************************* Hospital Bed List ****************************/
  public function hospital_bed_list($bed_type_id = null){
    $pharm_user_id = $this->session->userdata('pharm_user_id');
    $pharm_company_id = $this->session->userdata('pharm_company_id');
    $pharm_role_id = $this->session->userdata('pharm_role_id');
    if($pharm_user_id == '' || $pharm_company_id == ''){ header('location:'.base_url().'User'); }

    $val = '0';
    if($bed_type_id == '1'){ $bed_type = 'avlb_regular_bed >'; }
    elseif ($bed_type_id == '2') { $bed_type = 'avlb_oxygen_bed >'; }
    elseif ($bed_type_id == '3') { $bed_type = 'avlb_icu_bed >'; }
    elseif ($bed_type_id == '4') { $bed_type = 'avlb_special_bed >'; }
    else{ $bed_type = '';  $val = ''; }

    $data['hospital_list'] = $this->Master_Model->get_list_by_id3($pharm_company_id, 'hospital_status', '1', $bed_type, $val, '', '', 'hospital_name', 'ASC', 'hospital');

    $data['page'] = 'Hospital Bed List';
    $this->load->view('Admin/Include/head', $data);
    $this->load->view('Admin/Include/navbar', $data);
    $this->load->view('Admin/Hospital/hospital_bed_list', $data);
    $this->load->view('Admin/Include/footer', $data);
  }








/*************************************************************************************************/
  public function get_bed_count_by_hospital(){
    $hospital_id = $this->input->post('hospital_id');
    $hospital_info = $this->Master_Model->get_info_arr_fields('tot_regular_bed, avlb_regular_bed, tot_oxygen_bed, avlb_oxygen_bed, tot_icu_bed, avlb_icu_bed, tot_special_bed, avlb_special_bed','hospital_id', $hospital_id, 'hospital');
    $data['tot_regular_bed'] = $hospital_info[0]['tot_regular_bed'];
    $data['avlb_regular_bed'] = $hospital_info[0]['avlb_regular_bed'];
    $data['tot_oxygen_bed'] = $hospital_info[0]['tot_oxygen_bed'];
    $data['avlb_oxygen_bed'] = $hospital_info[0]['avlb_oxygen_bed'];
    $data['tot_icu_bed'] = $hospital_info[0]['tot_icu_bed'];
    $data['avlb_icu_bed'] = $hospital_info[0]['avlb_icu_bed'];
    $data['tot_special_bed'] = $hospital_info[0]['tot_special_bed'];
    $data['avlb_special_bed'] = $hospital_info[0]['avlb_special_bed'];

    echo json_encode($data);
  }
}
?>
