<?php
defined('BASEPATH') OR exit('No direct script access allowed');

  class Hos_User extends CI_Controller{
    public function __construct(){
      parent::__construct();
      date_default_timezone_set('Asia/Kolkata');
    }
    public function logout(){
      // $this->session->sess_destroy();
      $this->session->unset_userdata('hosp_user_id');
      $this->session->unset_userdata('hosp_hospital_id');
      $this->session->unset_userdata('hosp_role_id');
      header('location:'.base_url().'Hos_User');
    }

    /**************************      Login      ********************************/
      public function index(){
        $hosp_user_id = $this->session->userdata('hosp_user_id');
        $hosp_hospital_id = $this->session->userdata('hosp_hospital_id');
        $hosp_role_id = $this->session->userdata('hosp_role_id');
        if($hosp_user_id == '' && $hosp_hospital_id == ''){
          $this->form_validation->set_rules('mobile', 'Mobile No', 'trim|required');
          $this->form_validation->set_rules('password', 'Password', 'trim|required');
          if ($this->form_validation->run() == FALSE) {
          	$this->load->view('Hospital/User/login');
          } else{
            $mobile = $this->input->post('mobile');
            $password = $this->input->post('password');

            $login = $this->Hospital_Model->check_login($mobile, $password);
            // print_r($login);
            if($login == null){
              $this->session->set_flashdata('msg','login_error');
              header('location:'.base_url().'Hos_User');
            } else{
              // echo 'null not';
              $this->session->set_userdata('hosp_user_id', $login[0]['hospital_user_id']);
              $this->session->set_userdata('hosp_hospital_id', $login[0]['hospital_id']);
              $this->session->set_userdata('hosp_role_id', $login[0]['hospital_role_id']);
              $this->session->set_userdata('hosp_company_id', $login[0]['company_id']);
              // $this->session->set_userdata('branch_id', $login[0]['branch_id']);
              header('location:'.base_url().'Hos_User/dashboard');
            }
          }
        }
        else{
          header('location:'.base_url().'Hos_User/dashboard');
        }
      }

  /**************************      Dashboard      ********************************/
    public function dashboard(){
      $hosp_user_id = $this->session->userdata('hosp_user_id');
      $hosp_hospital_id = $this->session->userdata('hosp_hospital_id');
      $hosp_role_id = $this->session->userdata('hosp_role_id');
      if($hosp_user_id == '' || $hosp_hospital_id == ''){ header('location:'.base_url().'Hos_User'); }
      $data['regular_bed_cnt'] = $this->Master_Model->get_sum('','avlb_regular_bed','hospital_status','1','hospital_id',$hosp_hospital_id,'','','hospital');
      $data['oxygen_bed_cnt'] = $this->Master_Model->get_sum('','avlb_oxygen_bed','hospital_status','1','hospital_id',$hosp_hospital_id,'','','hospital');
      $data['icu_bed_cnt'] = $this->Master_Model->get_sum('','avlb_icu_bed','hospital_status','1','hospital_id',$hosp_hospital_id,'','','hospital');
      $data['special_bed_cnt'] = $this->Master_Model->get_sum('','avlb_special_bed','hospital_status','1','hospital_id',$hosp_hospital_id,'','','hospital');
      $data['page'] = 'Hospital Dashboard';
      $this->load->view('Hospital/Include/head', $data);
      $this->load->view('Hospital/Include/navbar', $data);
      $this->load->view('Hospital/User/dashboard', $data);
      $this->load->view('Hospital/Include/footer', $data);
    }



  }
?>
