<?php
defined('BASEPATH') OR exit('No direct script access allowed');

  class Hos_Master extends CI_Controller{
    public function __construct(){
      parent::__construct();
      date_default_timezone_set('Asia/Kolkata');
    }

    public function index(){
      header('location:'.base_url().'Hos_User/dashboard');
    }

/******************************************* Hospital *********************************/
    public function hospital(){
      $hosp_user_id = $this->session->userdata('hosp_user_id');
      $hosp_hospital_id = $this->session->userdata('hosp_hospital_id');
      $hosp_role_id = $this->session->userdata('hosp_role_id');
      if($hosp_user_id == '' || $hosp_hospital_id == ''){ header('location:'.base_url().'Hos_User'); }

      $this->form_validation->set_rules('hospital_name', 'First Name', 'trim|required');
      if ($this->form_validation->run() != FALSE) {
        // $hospital_status = $this->input->post('hospital_status');
        // if(!isset($hospital_status)){ $hospital_status = '1'; }
        $update_data = $_POST;
        $hospital_facility = implode(", ", $_POST['hospital_facility']);
        $hospital_accrediation = implode(", ", $_POST['hospital_accrediation']);
        $hospital_pay_mode = implode(", ", $_POST['hospital_pay_mode']);

        $update_data['hospital_facility'] = $hospital_facility;
        $update_data['hospital_accrediation'] = $hospital_accrediation;
        $update_data['hospital_pay_mode'] = $hospital_pay_mode;

        unset($update_data['old_hospital_img']);
        // $update_data['hospital_status'] = $hospital_status;
        // $update_data['hospital_addedby'] = $pharm_user_id;
        $this->Master_Model->update_info('hospital_id', $hosp_hospital_id, 'hospital', $update_data);

        if($_FILES['hospital_image']['name']){
          $time = time();
          $image_name = 'hospital_'.$hosp_hospital_id.'_'.$time;
          $config['upload_path'] = 'assets/images/hospital/';
          $config['allowed_types'] = 'jpg|jpeg|png|gif';
          $config['file_name'] = $image_name;
          $filename = $_FILES['hospital_image']['name'];
          $ext = pathinfo($filename, PATHINFO_EXTENSION);
          $this->upload->initialize($config); // if upload library autoloaded
          if ($this->upload->do_upload('hospital_image') && $hosp_hospital_id && $image_name && $ext && $filename){
            $hospital_image_up['hospital_image'] =  $image_name.'.'.$ext;
            $this->Master_Model->update_info('hospital_id', $hosp_hospital_id, 'hospital', $hospital_image_up);
            if($_POST['old_hospital_img']){ unlink("assets/images/hospital/".$_POST['old_hospital_img']); }
            $this->session->set_flashdata('upload_success','File Uploaded Successfully');
          }
          else{
            $error = $this->upload->display_errors();
            $this->session->set_flashdata('upload_error',$error);
          }
        }

        $this->session->set_flashdata('update_success','success');
        header('location:'.base_url().'Hos_Master/hospital');
      }

      $hospital_info = $this->Master_Model->get_info_arr('hospital_id',$hosp_hospital_id,'hospital');
      if(!$hospital_info){ header('location:'.base_url().'Hos_User'); }
      $data['update'] = 'update';
      $data['update_hospital'] = 'update';
      $data['hospital_info'] = $hospital_info[0];
      $data['act_link'] = base_url().'Hos_Master/hospital';
      $state_id = $hospital_info[0]['state_id'];
      $data['state_list'] = $this->Master_Model->get_list_by_id3('','country_id','101','','','','','state_name','ASC','state');
      $data['city_list'] = $this->Master_Model->get_list_by_id3('','state_id',$state_id,'','','','','city_name','ASC','city');
      $data['facility_list'] = $this->Master_Model->get_list_by_id3('','facility_status','1','','','','','facility_name','ASC','facility');
      $data['payment_mode_list'] = $this->Master_Model->get_list_by_id3('','payment_mode_status','1','','','','','payment_mode_name','ASC','payment_mode');

      $data['hospital_list'] = $this->Master_Model->get_list_by_id3('','hospital_id',$hosp_hospital_id,'','','','','hospital_id','DESC','hospital');
      $this->load->view('Hospital/Include/head', $data);
      $this->load->view('Hospital/Include/navbar', $data);
      $this->load->view('Hospital/User/hospital', $data);
      $this->load->view('Hospital/Include/footer', $data);
    }

/*********************************************** Package *****************************************/
    // Add Package...
    public function cov_package(){
      $hosp_user_id = $this->session->userdata('hosp_user_id');
      $hosp_hospital_id = $this->session->userdata('hosp_hospital_id');
      $hosp_role_id = $this->session->userdata('hosp_role_id');
      $hospital_id = $this->session->userdata('hosp_hospital_id');
      if($hosp_user_id == '' || $hosp_hospital_id == ''){ header('location:'.base_url().'Hos_User'); }

      $hospital_info = $this->Master_Model->get_info_arr('hospital_id',$hospital_id,'hospital');
      if(!$hospital_info){ header('location:'.base_url().'Hos_User'); }

      $this->form_validation->set_rules('cov_package_name', 'cov_package title', 'trim|required');
      if ($this->form_validation->run() != FALSE) {
        $cov_package_status = $this->input->post('cov_package_status');
        if(!isset($cov_package_status)){ $cov_package_status = '1'; }
        $save_data = $_POST;
        $save_data['cov_package_status'] = $cov_package_status;
        $save_data['hospital_id'] = $hospital_id;
        $save_data['cov_package_addedby_hosp'] = $hosp_user_id;
        $cov_package_id = $this->Master_Model->save_data('cov_package', $save_data);

        if(isset($_FILES['cov_package_file_name']['name'])){
          $this->load->library('upload');
          $files = $_FILES;
          $cpt = count($_FILES['cov_package_file_name']['name']);
          for($i=0; $i<$cpt; $i++)
          {
            $j = $i+1;
            $time = time();
            $image_name = 'cov_package_'.$hospital_id.'_'.$cov_package_id.'_'.$time;
              $_FILES['cov_package_file_name']['name']= $files['cov_package_file_name']['name'][$i];
              $_FILES['cov_package_file_name']['type']= $files['cov_package_file_name']['type'][$i];
              $_FILES['cov_package_file_name']['tmp_name']= $files['cov_package_file_name']['tmp_name'][$i];
              $_FILES['cov_package_file_name']['error']= $files['cov_package_file_name']['error'][$i];
              $_FILES['cov_package_file_name']['size']= $files['cov_package_file_name']['size'][$i];
              $config['upload_path'] = 'assets/images/cov_package/';
              $config['allowed_types'] = 'gif|jpg|png|pdf|docx|ppt';
              $config['file_name'] = $image_name;
              $config['overwrite']     = FALSE;
              $filename = $files['cov_package_file_name']['name'][$i];
              $ext = pathinfo($filename, PATHINFO_EXTENSION);
              $this->upload->initialize($config);
              if($this->upload->do_upload('cov_package_file_name')){
                $file_data['cov_package_file_name'] = $image_name.'.'.$ext;
                $file_data['cov_package_id'] = $cov_package_id;
                $this->Master_Model->save_data('cov_package_file', $file_data);
              }
              else{
                $error = $this->upload->display_errors();
                $this->session->set_flashdata('status',$this->upload->display_errors());
              }
          }
        }

        $this->session->set_flashdata('save_success','success');
        header('location:'.base_url().'Hos_Master/cov_package');
      }


      // $data['update'] = 'update';
      // $data['update_cov_package'] = 'update';
      $data['hospital_info'] = $hospital_info[0];
      $data['act_link'] = base_url().'Hos_Master/cov_package';
      $data['hospital_type_list'] = $this->Master_Model->get_list_by_id3('','','','','','','','hospital_type_id','ASC','hospital_type');

      $data['cov_package_list'] = $this->Master_Model->get_list_by_id3('','hospital_id',$hospital_id,'','','','','cov_package_id','DESC','cov_package');
      $data['page'] = 'Package';
      $this->load->view('Hospital/Include/head', $data);
      $this->load->view('Hospital/Include/navbar', $data);
      $this->load->view('Hospital/User/cov_package', $data);
      $this->load->view('Hospital/Include/footer', $data);
    }

    // Edit Package...
    public function edit_cov_package($cov_package_id){
      $hosp_user_id = $this->session->userdata('hosp_user_id');
      $hosp_hospital_id = $this->session->userdata('hosp_hospital_id');
      $hosp_role_id = $this->session->userdata('hosp_role_id');
      $hospital_id = $this->session->userdata('hosp_hospital_id');
      if($hosp_user_id == '' || $hosp_hospital_id == ''){ header('location:'.base_url().'Hos_User'); }

      $hospital_info = $this->Master_Model->get_info_arr('hospital_id',$hospital_id,'hospital');
      if(!$hospital_info){ header('location:'.base_url().'Hos_User'); }

      $this->form_validation->set_rules('cov_package_name', 'cov_package title', 'trim|required');
      if ($this->form_validation->run() != FALSE) {
        $cov_package_status = $this->input->post('cov_package_status');
        if(!isset($cov_package_status)){ $cov_package_status = '1'; }
        $update_data = $_POST;
        unset($update_data['input']);
        $update_data['cov_package_status'] = $cov_package_status;
        $update_data['cov_package_addedby_hosp'] = $hosp_user_id;
        $this->Master_Model->update_info('cov_package_id', $cov_package_id, 'cov_package', $update_data);

        if(isset($_FILES['cov_package_file_name']['name'])){
          $this->load->library('upload');
          $files = $_FILES;
          $cpt = count($_FILES['cov_package_file_name']['name']);
          for($i=0; $i<$cpt; $i++)
          {
            $j = $i+1;
            $time = time();
            $image_name = 'cov_package_'.$hospital_id.'_'.$cov_package_id.'_'.$time;
              $_FILES['cov_package_file_name']['name']= $files['cov_package_file_name']['name'][$i];
              $_FILES['cov_package_file_name']['type']= $files['cov_package_file_name']['type'][$i];
              $_FILES['cov_package_file_name']['tmp_name']= $files['cov_package_file_name']['tmp_name'][$i];
              $_FILES['cov_package_file_name']['error']= $files['cov_package_file_name']['error'][$i];
              $_FILES['cov_package_file_name']['size']= $files['cov_package_file_name']['size'][$i];
              $config['upload_path'] = 'assets/images/cov_package/';
              $config['allowed_types'] = 'gif|jpg|png|pdf|docx|ppt';
              $config['file_name'] = $image_name;
              $config['overwrite']     = FALSE;
              $filename = $files['cov_package_file_name']['name'][$i];
              $ext = pathinfo($filename, PATHINFO_EXTENSION);
              $this->upload->initialize($config);
              if($this->upload->do_upload('cov_package_file_name')){
                $file_data['cov_package_file_name'] = $image_name.'.'.$ext;
                $file_data['cov_package_id'] = $cov_package_id;
                $this->Master_Model->save_data('cov_package_file', $file_data);
              }
              else{
                $error = $this->upload->display_errors();
                $this->session->set_flashdata('status',$this->upload->display_errors());
              }
          }
        }

        $this->session->set_flashdata('update_success','success');
        header('location:'.base_url().'Hos_Master/cov_package');
      }

      $cov_package_info = $this->Master_Model->get_info_arr('cov_package_id',$cov_package_id,'cov_package');
      if(!$cov_package_info){ header('location:'.base_url().'Hos_Master/cov_package'); }

      $data['update'] = 'update';
      // $data['update_cov_package'] = 'update';
      $data['hospital_info'] = $hospital_info[0];
      $data['cov_package_info'] = $cov_package_info[0];
      $data['act_link'] = base_url().'Hos_Master/edit_cov_package'.$cov_package_id;
      $data['hospital_type_list'] = $this->Master_Model->get_list_by_id3('','','','','','','','hospital_type_id','ASC','hospital_type');
      $data['cov_package_file_list'] = $this->Master_Model->get_list_by_id3('','cov_package_id',$cov_package_id,'','','','','cov_package_file_id','ASC','cov_package_file');

      $data['cov_package_list'] = $this->Master_Model->get_list_by_id3('','hospital_id',$hospital_id,'','','','','cov_package_id','DESC','cov_package');
      $data['page'] = 'Package';
      $this->load->view('Hospital/Include/head', $data);
      $this->load->view('Hospital/Include/navbar', $data);
      $this->load->view('Hospital/User/cov_package', $data);
      $this->load->view('Hospital/Include/footer', $data);
    }

    // Delete Package...
    public function delete_cov_package($cov_package_id){
      $hosp_user_id = $this->session->userdata('hosp_user_id');
      $hosp_hospital_id = $this->session->userdata('hosp_hospital_id');
      $hosp_role_id = $this->session->userdata('hosp_role_id');
      if($hosp_user_id == '' || $hosp_hospital_id == ''){ header('location:'.base_url().'Hos_User'); }
      // $cov_package_info = $this->Master_Model->get_info_arr_fields('cov_package_image, cov_package_id', 'cov_package_id', $cov_package_id, 'cov_package');
      // if($cov_package_info){
      //   $cov_package_image = $cov_package_info[0]['cov_package_image'];
      //   if($cov_package_image){ unlink("assets/images/cov_package/".$cov_package_image); }
      // }
      $this->Master_Model->delete_info('cov_package_id', $cov_package_id, 'cov_package');
      $this->Master_Model->delete_info('cov_package_id', $cov_package_id, 'cov_package_file');
      $this->session->set_flashdata('delete_success','success');
      header('location:'.base_url().'Hos_Master/cov_package');
    }

    // Delete Package File
    public function delete_cov_package_file(){
      $cov_package_file_id = $this->input->post('cov_package_file_id');
      $cov_package_info = $this->Master_Model->get_info_arr_fields('cov_package_file_name, cov_package_file_id', 'cov_package_file_id', $cov_package_file_id, 'cov_package_file');
      if($cov_package_info){
        $cov_package_file_name = $cov_package_info[0]['cov_package_file_name'];
        if($cov_package_file_name){ unlink("assets/images/cov_package/".$cov_package_file_name); }
      }
      $this->Master_Model->delete_info('cov_package_file_id', $cov_package_file_id, 'cov_package_file');
    }

  /****************************************** Available Bed ****************************************/
    // Edit/Update Available Bed Count...
    public function available_bed(){
      $hosp_user_id = $this->session->userdata('hosp_user_id');
      $hosp_hospital_id = $this->session->userdata('hosp_hospital_id');
      $hosp_role_id = $this->session->userdata('hosp_role_id');
      if($hosp_user_id == '' || $hosp_hospital_id == ''){ header('location:'.base_url().'Hos_User'); }

      $this->form_validation->set_rules('hospital_id', 'Hospital Name', 'trim|required');
      if ($this->form_validation->run() != FALSE) {
        $hospital_id = $_POST['hospital_id'];
        $update_data = $_POST;
        unset($update_data['hospital_id']);
        $this->Master_Model->update_info('hospital_id', $hospital_id, 'hospital', $update_data);

        $this->session->set_flashdata('update_success','success');
        header('location:'.base_url().'Hos_Master/available_bed');
      }
      $data['update'] = 'update';
      $data['update_available_bed'] = 'update';
      $data['act_link'] = base_url().'Hos_Master/available_bed';

      $data['hospital_list'] = $this->Master_Model->get_list_by_id3('','hospital_id',$hosp_hospital_id,'','','','','hospital_name','ASC','hospital');
      $data['page'] = 'Available Bed';
      $this->load->view('Hospital/Include/head', $data);
      $this->load->view('Hospital/Include/navbar', $data);
      $this->load->view('Hospital/User/available_bed', $data);
      $this->load->view('Hospital/Include/footer', $data);
    }

  }
?>
