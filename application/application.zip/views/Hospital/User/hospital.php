<!DOCTYPE html>
<html>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header pt-0 pb-2">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-12 text-left mt-2">
            <h4>Hospital</h4>
          </div>
        </div>
      </div>
    </section>

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card collapsed-card">
              <div class="card-header">
                <h3 class="card-title"> Update Hospital</h3>
                <div class="card-tools">
                  <?php
                    echo '<button type="button" class="btn btn-sm btn-primary" data-card-widget="collapse">Update</button>';
                  ?>
                </div>
              </div>
              <!--  -->
                <div class="card-body p-0 " style="display: none;">
                  <form class="input_form m-0" id="form_action" role="form" action="" method="post" autocomplete="off" enctype="multipart/form-data">
                    <div class="row p-4">
                      <!-- <div class="form-group col-md-3 select_sm">
                        <label>Hospital Type</label>
                        <select class="form-control select2 form-control-sm" name="hospital_type" id="hospital_type" data-placeholder="Select Hospital Type" required>
                          <option value="">Select Hospital Type</option>
                          <option value="1" <?php if(isset($hospital_info) && $hospital_info['hospital_type'] == '1'){ echo 'selected'; } ?>>Hospital</option>
                          <option value="2" <?php if(isset($hospital_info) && $hospital_info['hospital_type'] == '2'){ echo 'selected'; } ?>>Quarantine Center</option>
                        </select>
                      </div> -->
                      <div class="form-group col-md-12 ">
                        <label>Enter Hospital Name</label>
                        <input type="text" class="form-control form-control-sm" name="hospital_name" id="hospital_name" value="<?php if(isset($hospital_info)){ echo $hospital_info['hospital_name']; } ?>" placeholder="Enter Hospital Name" required>
                      </div>
                      <div class="form-group col-md-12 ">
                        <label>Address</label>
                        <input type="text" class="form-control form-control-sm" name="hospital_address" id="hospital_address" value="<?php if(isset($hospital_info)){ echo $hospital_info['hospital_address']; } ?>" placeholder="Enter Address" required>
                      </div>
                      <div class="form-group col-md-4 select_sm">
                        <label>Select State</label>
                        <select class="form-control select2" name="state_id" id="state_id" data-placeholder="Select State" required>
                          <option value="">Select State</option>
                          <?php if(isset($state_list)){ foreach ($state_list as $list) { ?>
                          <option value="<?php echo $list->state_id; ?>" <?php if(isset($hospital_info) && $hospital_info['state_id'] == $list->state_id){ echo 'selected'; } ?>><?php echo $list->state_name; ?></option>
                          <?php } } ?>
                        </select>
                      </div>
                      <div class="form-group col-md-4 select_sm">
                        <label>Select City</label>
                        <select class="form-control select2" name="city_id" id="city_id" data-placeholder="Select City" required>
                          <option value="">Select City</option>
                          <?php if(isset($city_list)){ foreach ($city_list as $list) { ?>
                          <option value="<?php echo $list->city_id; ?>" <?php if(isset($hospital_info) && $hospital_info['city_id'] == $list->city_id){ echo 'selected'; } ?>><?php echo $list->city_name; ?></option>
                          <?php } } ?>
                        </select>
                      </div>
                      <div class="form-group col-md-4 ">
                        <label>PinCode</label>
                        <input type="number" class="form-control form-control-sm" name="hospital_pincode" id="hospital_pincode" value="<?php if(isset($hospital_info)){ echo $hospital_info['hospital_pincode']; } ?>" placeholder="PinCode" required>
                      </div>

                      <div class="form-group col-md-4 ">
                        <label>Mobile No 1</label>
                        <input type="number" class="form-control form-control-sm" name="hospital_mobile" id="hospital_mobile" value="<?php if(isset($hospital_info)){ echo $hospital_info['hospital_mobile']; } ?>" placeholder="Mobile No 1" required>
                      </div>
                      <div class="form-group col-md-4 ">
                        <label>Mobile No 2 / Landline No.</label>
                        <input type="number" class="form-control form-control-sm" name="hospital_mobile2" id="hospital_mobile2" value="<?php if(isset($hospital_info)){ echo $hospital_info['hospital_mobile2']; } ?>" placeholder="Mobile No 2 / Landline No." required>
                      </div>
                      <div class="form-group col-md-4 ">
                        <label>Email</label>
                        <input type="email" class="form-control form-control-sm" name="hospital_email" id="hospital_email" value="<?php if(isset($hospital_info)){ echo $hospital_info['hospital_email']; } ?>" placeholder="Email" required>
                      </div>

                      <div class="form-group col-md-6 ">
                        <label>Longitude</label>
                        <input type="number" class="form-control form-control-sm" name="hospital_longitude" id="hospital_longitude" value="<?php if(isset($hospital_info)){ echo $hospital_info['hospital_longitude']; } ?>" placeholder="Enter Longitude" required>
                      </div>
                      <div class="form-group col-md-6 ">
                        <label>Latitude</label>
                        <input type="number" class="form-control form-control-sm" name="hospital_latitude" id="hospital_latitude" value="<?php if(isset($hospital_info)){ echo $hospital_info['hospital_latitude']; } ?>" placeholder="Enter Latitude" required>
                      </div>

                      <div class="form-group col-md-3 ">
                        <label>Established On</label>
                        <input type="number" class="form-control form-control-sm" name="hospital_est_on" id="hospital_est_on" value="<?php if(isset($hospital_info)){ echo $hospital_info['hospital_est_on']; } ?>" placeholder="Established On" required>
                      </div>
                      <div class="form-group col-md-3 ">
                        <label>Total No. of Beds</label>
                        <input type="number" class="form-control form-control-sm" name="hospital_num_beds" id="hospital_num_beds" value="<?php if(isset($hospital_info)){ echo $hospital_info['hospital_num_beds']; } ?>" placeholder="Total No. of Beds" required>
                      </div>
                      <div class="form-group col-md-3 ">
                        <label>Total No. of Doctors</label>
                        <input type="number" class="form-control form-control-sm" name="hospital_num_doctors" id="hospital_num_doctors" value="<?php if(isset($hospital_info)){ echo $hospital_info['hospital_num_doctors']; } ?>" placeholder="Total No. of Doctors" required>
                      </div>
                      <div class="form-group col-md-3 ">
                        <label>Total No. of Ambulances</label>
                        <input type="number" class="form-control form-control-sm" name="hospital_num_ambul" id="hospital_num_ambul" value="<?php if(isset($hospital_info)){ echo $hospital_info['hospital_num_ambul']; } ?>" placeholder="Total No. of Ambulances" required>
                      </div>

                      <div class="form-group col-md-12 ">
                        <label>Overview of Hospital</label>
                        <textarea class="textarea form-control form-control-sm" name="hospital_overview" id="hospital_overview"  rows="4"><?php if(isset($hospital_info)){ echo $hospital_info['hospital_overview']; } ?></textarea>
                      </div>

                      <div class="form-group col-md-6 select_sm">
                        <label>Amenities(Facilities)</label>
                        <select class="form-control select2 form-control-sm" multiple name="hospital_facility[]" id="hospital_facility[]" data-placeholder="Select Amenities(Facilities)" required>
                          <option value="">Select Amenities(Facilities)</option>
                          <?php if(isset($facility_list)){ foreach ($facility_list as $list) { ?>
                          <option value="<?php echo $list->facility_id; ?>"
                            <?php if(isset($hospital_info)) {
                              $str_arr = explode (",", $hospital_info['hospital_facility']);
                              foreach ($str_arr as $x) {
                                if($x == $list->facility_id) { echo "selected"; }
                              }
                            } ?>
                          ><?php echo $list->facility_name; ?></option>
                          <?php } } ?>
                        </select>
                      </div>
                      <div class="form-group col-md-6 select_sm">
                        <label>Accrediation</label>
                        <select class="form-control select2 form-control-sm" multiple name="hospital_accrediation[]" id="hospital_accrediation[]" data-placeholder="Select Accrediation" required>
                          <option value="">Select Accrediation</option>
                          <?php if(isset($facility_list)){ foreach ($facility_list as $list) { ?>
                          <option value="<?php echo $list->facility_id; ?>"
                            <?php if(isset($hospital_info)) {
                              $str_arr = explode (",", $hospital_info['hospital_accrediation']);
                              foreach ($str_arr as $x) {
                                if($x == $list->facility_id) { echo "selected"; }
                              }
                            } ?>
                          ><?php echo $list->facility_name; ?></option>
                          <?php } } ?>
                        </select>
                      </div>
                      <div class="form-group col-md-6 select_sm">
                        <label>Payment Mode</label>
                        <select class="form-control select2 form-control-sm" multiple name="hospital_pay_mode[]" id="hospital_pay_mode[]" data-placeholder="Select Payment Mode" required>
                          <?php if(isset($payment_mode_list)){ foreach ($payment_mode_list as $list) { ?>
                          <option value="<?php echo $list->payment_mode_id; ?>"
                            <?php if(isset($hospital_info)) {
                              $str_arr = explode (",", $hospital_info['hospital_pay_mode']);
                              foreach ($str_arr as $x) {
                                if($x == $list->payment_mode_id) { echo "selected"; }
                              }
                            } ?>
                          ><?php echo $list->payment_mode_name; ?></option>
                          <?php } } ?>
                        </select>
                      </div>
                      <div class="form-group col-md-6">
                      </div>
                      <?php if(!isset($hospital_info)){ ?>
                        <div class="form-group col-md-4 ">
                          <label>Password</label>
                          <input type="passwrd" class="form-control form-control-sm" name="hospital_password" id="hospital_password" value="" placeholder="Enter Password" <?php if(!isset($hospital_info)){ echo 'required'; } ?> >
                        </div>
                        <div class="form-group col-md-4 ">
                          <label>Confirm Password</label>
                          <input type="passwrd" class="form-control form-control-sm" id="hospital_con_password" value="" placeholder="Confirm Password" <?php if(!isset($hospital_info)){ echo 'required'; } ?>>
                        </div>
                        <div class="form-group col-md-4 ">
                        </div>
                      <?php } ?>

                      <div class="form-group col-md-3">
                        <label>Hospital Logo</label>
                        <input type="file" class="form-control form-control-sm" name="hospital_image" id="hospital_image" >
                      </div>
                      <div class="form-group col-md-3">
                        <?php if(isset($hospital_info) && $hospital_info['hospital_image']){ ?>
                          <label>Uploaded Hospital Logo</label><br>
                          <img width="200px" src="<?php echo base_url() ?>assets/images/hospital/<?php echo $hospital_info['hospital_image'];  ?>" alt="Hospital Image">
                          <input type="hidden" name="old_hospital_img" value="<?php echo $hospital_info['hospital_image']; ?>">
                        <?php } ?>
                      </div>
                    </div>
                    <div class="card-footer clearfix" style="display: block;">
                      <div class="row">
                        <div class="col-md-6 text-left">
                          <!-- <div class="custom-control custom-checkbox">
                            <input class="custom-control-input" type="checkbox" name="hospital_status" id="hospital_status" value="0" <?php if(isset($hospital_info) && $hospital_info['hospital_status'] == 0){ echo 'checked'; } ?>>
                            <label for="hospital_status" class="custom-control-label">Disable This Hospital</label>
                          </div> -->
                        </div>
                        <div class="col-md-6 text-right">
                          <a href="<?php echo base_url(); ?>Hos_Master/hospital" class="btn btn-sm btn-default px-4 mx-4">Cancel</a>
                          <?php if(isset($update)){
                            echo '<button class="btn btn-sm btn-primary float-right px-4">Update</button>';
                          } else{
                            echo '<button class="btn btn-sm btn-success float-right px-4">Save</button>';
                          } ?>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
            </div>
          </div>


          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">List All Hospital Information</h3>
              </div>
              <div class="card-body p-2">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th class="d-none">#</th>
                    <th>Hospital Name</th>
                    <th class="wt_50">Type</th>
                    <th class="wt_75">Mobile</th>
                    <th class="wt_75">City</th>
                    <th class="wt_50">Image</th>
                    <th class="wt_50">Status</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php if(isset($hospital_list)){
                    $i=0; foreach ($hospital_list as $list) { $i++;
                      $city_info = $this->Master_Model->get_info_arr_fields3('city_name', '', 'city_id', $list->city_id, '', '', '', '', 'city');
                    ?>
                    <tr>
                      <td class="d-none"><?php echo $i; ?></td>
                      <td><?php echo $list->hospital_name; ?></td>
                      <td>
                        <?php if($list->hospital_type == 1){ echo '<span class="text-success">Hospital</span>'; }
                          else{ echo '<span class="text-primary">Quarantine</span>'; } ?>
                      </td>
                      <td><?php echo $list->hospital_mobile; ?></td>
                      <td><?php if($city_info){ echo $city_info[0]['city_name']; } ?></td>
                      <td><img height="50px" src="<?php echo base_url() ?>assets/images/hospital/<?php echo $list->hospital_image;  ?>" alt="Hospital Image">
                      <td>
                        <?php if($list->hospital_status == 0){ echo '<span class="text-danger">Inactive</span>'; }
                          else{ echo '<span class="text-success">Active</span>'; } ?>
                      </td>
                    </tr>
                  <?php } } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  </div>

</body>
</html>

<script type="text/javascript">
  $("#state_id").on("change", function(){
    var state_id =  $('#state_id').find("option:selected").val();
    $.ajax({
      url:'<?php echo base_url(); ?>Master/get_city_by_state',
      type: 'POST',
      data: {"state_id":state_id},
      context: this,
      success: function(result){
        $('#city_id').html(result);
      }
    });
  });
</script>
