<!DOCTYPE html>
<html>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header pt-0 pb-2">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-12 text-left mt-2">
            <h4>Test Group</h4>
          </div>
        </div>
      </div>
    </section>

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card <?php if(!isset($update)){ echo 'collapsed-card'; } ?>">
              <div class="card-header">
                <h3 class="card-title"> <?php if(isset($update)){ echo 'Update'; } else{ echo 'Add New'; } ?> Test Group</h3>
                <div class="card-tools">
                  <?php if(!isset($update)){
                    echo '<button type="button" class="btn btn-sm btn-primary" data-card-widget="collapse">Add New</button>';
                  } else{
                    echo '<a href="'.base_url().'Master/test_group" type="button" class="btn btn-sm btn-outline-info" >Cancel Update</a>';
                  } ?>
                </div>
              </div>
              <!--  -->
                <div class="card-body p-0 " <?php if(isset($update)){ echo 'style="display: block;"'; } else{ echo 'style="display: none;"'; } ?>>
                  <form class="input_form m-0" id="form_action" role="form" action="" method="post" autocomplete="off" enctype="multipart/form-data">
                    <div class="row p-4">
                      <div class="form-group col-md-6 select_sm">
                        <label>Select Primary Test Group</label>
                        <select class="form-control select2 form-control-sm" name="primary_test_group_id" id="primary_test_group_id" data-placeholder="Select Primary Test Group" required>
                          <option value="">Select Primary Test Group</option>
                          <option value="-1" <?php if(isset($test_group_info) && $test_group_info['primary_test_group_id'] == 0){ echo 'selected'; } ?>>Set As Primary</option>
                          <?php if(isset($primary_test_group_list)){
                            foreach ($primary_test_group_list as $list) { ?>
                              <option value="<?php echo $list->test_group_id; ?>" <?php if(isset($test_group_info) && $test_group_info['primary_test_group_id'] == $list->test_group_id){ echo 'selected'; } ?>
                                <?php if(isset($test_group_info) && $test_group_info['test_group_id'] == $list->test_group_id){ echo 'disabled'; } ?>
                                ><?php echo $list->test_group_name; ?></option>
                          <?php } } ?>
                        </select>
                      </div>
                      <div class="form-group col-md-6 ">
                        <label>Enter Test Group Name</label>
                        <input type="text" class="form-control form-control-sm" name="test_group_name" id="test_group_name" value="<?php if(isset($test_group_info)){ echo $test_group_info['test_group_name']; } ?>" placeholder="Enter Test Group Name" required>
                      </div>
                      <div class="form-group col-md-12 ">
                        <label>Enter Test Group Description</label>
                        <textarea class="form-control form-control-sm" name="test_group_descr" id="test_group_descr"  rows="5" required><?php if(isset($test_group_info)){ echo $test_group_info['test_group_descr']; } ?></textarea>
                        <!-- <input type="text" class="form-control form-control-sm" name="test_group_name" id="test_group_name" value="<?php if(isset($test_group_info)){ echo $test_group_info['test_group_name']; } ?>" placeholder="Enter Test Group Name" required> -->
                      </div>
                      <div class="form-group col-md-6 ">
                        <label>Serial Order No.</label>
                        <input type="number" class="form-control form-control-sm" name="test_group_serial_no" id="test_group_serial_no" value="<?php if(isset($test_group_info)){ echo $test_group_info['test_group_serial_no']; } ?>" placeholder="Enter Serial Order No." required>
                      </div>
                      <div class="form-group col-md-6 ">
                        <label>Cost</label>
                        <input type="number" class="form-control form-control-sm" name="test_group_cost" id="test_group_cost" value="<?php if(isset($test_group_info)){ echo $test_group_info['test_group_cost']; } ?>" placeholder="Enter Cost" required>
                      </div>
                      <div class="form-group col-md-6">
                        <label>Test Group Image</label>
                        <input type="file" class="form-control form-control-sm" name="test_group_image" id="test_group_image" >
                      </div>
                      <div class="form-group col-md-6">
                        <?php if(isset($test_group_info) && $test_group_info['test_group_image']){ ?>
                          <label>Uploaded Test Group Image</label><br>
                          <img width="200px" src="<?php echo base_url() ?>assets/images/test_group/<?php echo $test_group_info['test_group_image'];  ?>" alt="Test Group Image">
                          <input type="hidden" name="old_test_group_img" value="<?php echo $test_group_info['test_group_image']; ?>">
                        <?php } ?>
                      </div>

                      <div class="form-group col-md-6">
                        <label>Test Group Icon</label>
                        <input type="file" class="form-control form-control-sm" name="test_group_icon" id="test_group_icon" >
                      </div>
                      <div class="form-group col-md-6">
                        <?php if(isset($test_group_info) && $test_group_info['test_group_icon']){ ?>
                          <label>Uploaded Test Group Icon</label><br>
                          <img width="200px" src="<?php echo base_url() ?>assets/images/test_group/<?php echo $test_group_info['test_group_icon'];  ?>" alt="Test Group Icon">
                          <input type="hidden" name="old_test_group_icon" value="<?php echo $test_group_info['test_group_icon']; ?>">
                        <?php } ?>
                      </div>
                    </div>
                    <div class="card-footer clearfix" style="display: block;">
                      <div class="row">
                        <div class="col-md-6 text-left">
                          <div class="custom-control custom-checkbox">
                            <input class="custom-control-input" type="checkbox" name="test_group_status" id="test_group_status" value="0" <?php if(isset($test_group_info) && $test_group_info['test_group_status'] == 0){ echo 'checked'; } ?>>
                            <label for="test_group_status" class="custom-control-label">Disable This Test Group</label>
                          </div>
                        </div>
                        <div class="col-md-6 text-right">
                          <a href="<?php base_url(); ?>Product/test_group" class="btn btn-sm btn-default px-4 mx-4">Cancel</a>
                          <?php if(isset($update)){
                            echo '<button class="btn btn-sm btn-primary float-right px-4">Update</button>';
                          } else{
                            echo '<button class="btn btn-sm btn-success float-right px-4" >Save</button>';
                          } ?>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
            </div>
          </div>


          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">List All Test Group Information</h3>
              </div>
              <div class="card-body p-2">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th class="d-none">#</th>
                    <th class="wt_50">Action</th>
                    <th>Test Group Name</th>
                    <th class="wt_75">Type</th>
                    <th class="wt_75">Cost</th>
                    <th class="wt_75">Image</th>
                    <th class="wt_75">Icon</th>
                    <th class="wt_50">Status</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php if(isset($test_group_list)){
                      $i=0; foreach ($test_group_list as $list) { $i++;
                        $cnt = $this->Master_Model->get_count('test_group_id ','','primary_test_group_id',$list->test_group_id,'','','','','test_group');
                    ?>
                    <tr>
                      <td class="d-none"><?php echo $i; ?></td>
                      <td class="text-center">
                        <div class="btn-group">
                          <a href="<?php echo base_url() ?>Master/edit_test_group/<?php echo $list->test_group_id; ?>" type="button" class="btn btn-sm btn-default"><i class="fa fa-edit text-primary"></i></a>
                          <?php if($cnt == 0){ ?>
                          <a href="<?php echo base_url() ?>Master/delete_test_group/<?php echo $list->test_group_id; ?>" type="button" class="btn btn-sm btn-default" onclick="return confirm('Delete this Test Group Information');"><i class="fa fa-trash text-danger"></i></a>
                          <?php } ?>
                        </div>
                      </td>
                      <td><?php echo $list->test_group_name; ?></td>
                      <td>
                        <?php if($list->is_primary == 0){ echo '<span class="text-info">Sub-Group</span>'; }
                          else{ echo '<span class="text-primary">Main-Group</span>'; } ?>
                      </td>
                      <td><?php echo $list->test_group_cost; ?></td>
                      <td><img height="50px" src="<?php echo base_url() ?>assets/images/test_group/<?php echo $list->test_group_image;  ?>" alt="Test Group Image">
                      <td><img height="50px" src="<?php echo base_url() ?>assets/images/test_group/<?php echo $list->test_group_icon;  ?>" alt="Test Group Icon">
                      <td>
                        <?php if($list->test_group_status == 0){ echo '<span class="text-danger">Inactive</span>'; }
                          else{ echo '<span class="text-success">Active</span>'; } ?>
                      </td>
                    </tr>
                  <?php } } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  </div>

</body>
</html>
