<!DOCTYPE html>
<html>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header pt-0 pb-2">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-12 text-left mt-2">
            <h4>COVID Package</h4>
          </div>
        </div>
      </div>
    </section>

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">

            <div class="card <?php if(!isset($update)){ echo 'collapsed-card'; } ?> card-default">
              <div class="card-header">
                <h3 class="card-title"> <?php if(isset($update)){ echo 'Update'; } else{ echo 'Add New'; } ?> COVID Package</h3>
                <div class="card-tools">
                  <?php
                  echo '<a href="'.base_url().'Hospital/hospital" type="button" class="btn btn-sm btn-outline-primary mr-2" >Hospital List</a>';
                  if(!isset($update)){
                    echo '<button type="button" class="btn btn-sm btn-primary" data-card-widget="collapse">Add New</button>';
                  } else{
                    echo '<a href="'.base_url().'Hospital/cov_package" type="button" class="btn btn-sm btn-outline-info" >Cancel Update</a>';
                  } ?>
                </div>
              </div>
              <!--  -->
              <div class="card-body p-0" <?php if(isset($update)){ echo 'style="display: block;"'; } else{ echo 'style="display: none;"'; } ?>>
                <form class="input_form m-0" id="form_action" role="form" action="" method="post" enctype="multipart/form-data">
                  <div class="row p-4">
                    <input type="hidden" name="hospital_type" value="<?php echo $hospital_info['hospital_type']; ?>">
                    <div class="form-group col-md-3 select_sm">
                      <label>Hospital Type</label>
                      <select class="form-control select2 form-control-sm" id="hospital_type" data-placeholder="Select Hospital Type" disabled>
                        <option value="">Select Hospital Type</option>
                        <?php if(isset($hospital_type_list)){ foreach ($hospital_type_list as $list) { ?>
                        <option value="<?php echo $list->hospital_type_id; ?>" <?php if(isset($hospital_info) && $hospital_info['hospital_type'] == $list->hospital_type_id){ echo 'selected'; } ?>><?php echo $list->hospital_type_name; ?></option>
                        <?php } } ?>
                      </select>
                    </div>
                    <div class="form-group col-md-9">
                      <label>Hospital Name</label>
                      <input type="text" class="form-control form-control-sm" id="cov_package_name" value="<?php if(isset($hospital_info)){ echo $hospital_info['hospital_name']; } ?>"  disabled >
                    </div>
                    <div class="form-group col-md-12 ">
                      <label>Address</label>
                      <input type="text" class="form-control form-control-sm" id="hospital_address" value="<?php if(isset($hospital_info)){ echo $hospital_info['hospital_address']; } ?>" disabled>
                    </div>

                    <div class="form-group col-md-12">
                      <label>COVID Package Name</label>
                      <input type="text" class="form-control form-control-sm" name="cov_package_name" id="cov_package_name" value="<?php if(isset($cov_package_info)){ echo $cov_package_info['cov_package_name']; } ?>"  placeholder="Enter Name of COVID Package" required >
                    </div>
                    <div class="form-group col-md-4">
                      <label>Package Price</label>
                      <input type="number" min="1" step="1" class="form-control form-control-sm" name="cov_package_price" id="cov_package_price" value="<?php if(isset($cov_package_info)){ echo $cov_package_info['cov_package_price']; } ?>"  placeholder="Enter Name of COVID Package" required >
                    </div>
                    <div class="form-group col-md-4">
                      <label>Package Duration (in Days)</label>
                      <input type="number" min="1" step="1" class="form-control form-control-sm" name="cov_package_duration" id="cov_package_duration" value="<?php if(isset($cov_package_info)){ echo $cov_package_info['cov_package_duration']; } ?>"  placeholder="Enter Number of Days" required >
                    </div>
                    <div class="form-group col-md-12">
                      <hr>
                    </div>
                    <div class="col-md-6">
                      <label style="font-size:16px !important;" >Add File</label>
                    </div>
                    <div class="col-md-6 text-right">
                      <button type="button" id="add_row" class="btn btn-sm btn-primary mb-3 mr-1" width="150px">Add Row</button>
                    </div>


                    <div class="col-md-10 offset-md-1">
                      <div class="" style="overflow-x:auto;">
                        <table id="myTable" class="table table-bordered tbl_list">
                          <thead>
                          <tr>
                            <th>File</th>
                            <th class="wt_50"></th>
                          </tr>
                          </thead>
                          <tbody>
                            <?php if(isset($cov_package_file_list)){ $i = 0; foreach ($cov_package_file_list as $list) { ?>
                              <input type="hidden" name="input[<?php echo $i; ?>][cov_package_file_id]" value="<?php echo $list->cov_package_file_id; ?>">
                              <tr>
                                <td>
                                  <a target="_blank" href="<?php echo base_url() ?>assets/images/cov_package/<?php echo $list->cov_package_file_name; ?>"><?php echo $list->cov_package_file_name; ?></a>
                                </td>
                                <td class="wt_50">
                                  <input type="hidden" class="cov_package_file_id" value="<?php echo $list->cov_package_file_id; ?>">
                                  <a class="rem_row"><i class="fa fa-trash text-danger"></i></a>
                                </td>
                              </tr>
                            <?php $i++;  } } else{ ?>
                              <tr>
                                <td>
                                  <input type="file" class="form-control form-control-sm" name="cov_package_file_name[]" required>
                                </td>
                                <td class="wt_50"></td>
                              </tr>
                            <?php } ?>
                          </tbody>
                        </table>
                      </div>
                    </div>


                  </div>
                  <div class="card-footer clearfix" style="display: block;">
                    <div class="row">
                      <div class="col-md-6 text-left">
                        <div class="custom-control custom-checkbox">
                          <input class="custom-control-input" type="checkbox" name="cov_package_status" id="cov_package_status" value="0" <?php if(isset($cov_package_info) && $cov_package_info['cov_package_status'] == 0){ echo 'checked'; } ?>>
                          <label for="cov_package_status" class="custom-control-label">Disable This COVID Package</label>
                        </div>
                      </div>
                      <div class="col-md-6 text-right">
                        <a href="<?php base_url(); ?>Hospital/cov_package" class="btn btn-sm btn-default px-4 mx-4">Cancel</a>
                        <?php if(isset($update)){
                          echo '<button class="btn btn-sm btn-primary float-right px-4">Update</button>';
                        } else{
                          echo '<button class="btn btn-sm btn-success float-right px-4">Save</button>';
                        } ?>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>

          <div class="col-md-12">
            <div class="card">
              <div class="card-header border-transparent">
                <h3 class="card-title">List All COVID Package</h3>
              </div>
              <div class="card-body p-2">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th class="d-none">#</th>
                    <th class="wt_50">Action</th>
                    <th>COVID Package Name</th>
                    <th class="wt_75">Treatment Price</th>
                    <th class="wt_75">Duration</th>
                    <th class="wt_75">Status</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php if(isset($cov_package_list)){
                      $i=0; foreach ($cov_package_list as $list) { $i++; ?>
                      <tr>
                        <td class="d-none"><?php echo $i; ?></td>
                        <td>
                          <div class="btn-group">
                            <a href="<?php echo base_url() ?>Hospital/edit_cov_package/<?php echo $list->cov_package_id; ?>" type="button" class="btn btn-sm btn-default"><i class="fa fa-edit text-primary"></i></a>
                            <a href="<?php echo base_url() ?>Hospital/delete_cov_package/<?php echo $list->cov_package_id; ?>" type="button" class="btn btn-sm btn-default" onclick="return confirm('Delete this COVID Package');"><i class="fa fa-trash text-danger"></i></a>
                          </div>
                        </td>
                        <td><?php echo $list->cov_package_name; ?></td>
                        <td>Rs.<?php echo $list->cov_package_price; ?></td>
                        <td><?php echo $list->cov_package_duration; ?> Days</td>
                        <td>
                          <?php if($list->cov_package_status == 0){ echo '<span class="text-danger">Inactive</span>'; }
                            else{ echo '<span class="text-success">Active</span>'; } ?>
                        </td>
                      </tr>
                    <?php } } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  </div>

</body>
</html>

<script type="text/javascript">
  // Add Row...
  <?php if(isset($update)){ ?>
  var i = <?php echo $i-1; ?>
  <?php } else { ?>
  var i = 0;
  <?php } ?>

  $('#add_row').click(function(){
    i++;
    var row = ''+
    '<tr>'+
      '<td>'+
        '<input type="file" class="form-control form-control-sm" name="cov_package_file_name[]" required>'+
      '</td>'+
      '<td class="wt_50"><a class="rem_row"><i class="fa fa-trash text-danger"></i></a></td>'+
    '</tr>';
    $('#myTable').append(row);
  });

  $('#myTable').on('click', '.rem_row', function () {
    $(this).closest('tr').remove();
    var cov_package_file_id = $(this).closest('tr').find('.cov_package_file_id').val();
    $.ajax({
      url:'<?php echo base_url(); ?>Hospital/delete_cov_package_file',
      type: 'POST',
      data: {"cov_package_file_id":cov_package_file_id},
      context: this,
      success: function(result){
        toastr.error('File Deleted successfully');
      }
    });
  });
</script>
