<!DOCTYPE html>
<html>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header pt-0 pb-2">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-12 text-left mt-2">
            <h4>Hospital List</h4>
          </div>
        </div>
      </div>
    </section>

    <section class="content">
      <div class="container-fluid">
        <div class="row">

          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">List Hospital</h3>
              </div>
              <div class="card-body p-2">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>#</th>
                    <!-- <th class="wt_75">Action</th> -->
                    <th>Hospital Name</th>
                    <th class="wt_75">Type</th>
                    <th class="wt_75">Mobile</th>
                    <th class="wt_75">City</th>
                    <th class="wt_50">Regular Bed</th>
                    <th class="wt_50">Oxygen Bed</th>
                    <th class="wt_50">ICU Bed</th>
                    <th class="wt_50">Special Bed</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php if(isset($hospital_list)){
                    $i=0; foreach ($hospital_list as $list) { $i++;
                      $city_info = $this->Master_Model->get_info_arr_fields3('city_name', '', 'city_id', $list->city_id, '', '', '', '', 'city');
                      $hospital_type_info = $this->Master_Model->get_info_arr_fields3('hospital_type_name', '', 'hospital_type_id', $list->hospital_type, '', '', '', '', 'hospital_type');
                    ?>
                    <tr>
                      <td><?php echo $i; ?></td>
                      <!-- <td class="text-center">
                        <div class="btn-group">
                          <a href="<?php echo base_url() ?>Hospital/edit_hospital/<?php echo $list->hospital_id; ?>" type="button" class="btn btn-sm btn-default"><i class="fa fa-edit text-primary"></i></a>
                        </div>
                        <br>
                        <a href="<?php echo base_url() ?>Hospital/cov_package_sess/<?php echo $list->hospital_id; ?>" type="button" class="btn btn-sm btn-info mt-1 py-0" > + Package</a>
                      </td> -->
                      <td><?php echo $list->hospital_name; ?></td>
                      <td class="wt_75"><?php if($hospital_type_info){ echo $hospital_type_info[0]['hospital_type_name']; } ?></td>
                      <td><?php echo $list->hospital_mobile; ?></td>
                      <td><?php if($city_info){ echo $city_info[0]['city_name']; } ?></td>
                      <td><?php echo $list->avlb_regular_bed; ?></td>
                      <td><?php echo $list->avlb_oxygen_bed; ?></td>
                      <td><?php echo $list->avlb_icu_bed; ?></td>
                      <td><?php echo $list->avlb_special_bed; ?></td>
                    </tr>
                  <?php } } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  </div>

</body>
</html>

<script type="text/javascript">
  $("#state_id").on("change", function(){
    var state_id =  $('#state_id').find("option:selected").val();
    $.ajax({
      url:'<?php echo base_url(); ?>Master/get_city_by_state',
      type: 'POST',
      data: {"state_id":state_id},
      context: this,
      success: function(result){
        $('#city_id').html(result);
      }
    });
  });
</script>
