<?php
  $pharm_user_id = $this->session->userdata('pharm_user_id');
  $pharm_company_id = $this->session->userdata('pharm_company_id');
  $pharm_role_id = $this->session->userdata('pharm_role_id');
  $company_info = $this->Master_Model->get_info_arr_fields('company_name','company_id', $pharm_company_id, 'company');
  $user_info = $this->Master_Model->get_info_arr_fields('user_name','user_id', $pharm_user_id, 'user');
?>
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
  <!-- Left navbar links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
    </li>
  </ul>
  <!-- Right navbar links -->
  <ul class="navbar-nav ml-auto">
    <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#" aria-expanded="false">
          <i class="far fa-user"></i>
          <?php echo $user_info[0]['user_name']; ?>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <!-- <div class="dropdown-item"> -->
            <div class="row">
              <div class="col-6 text-center">
                <!-- <a href="<?php echo base_url(); ?>Master/manage_profile" class="dropdown-item py-4"> -->
                <a href="" class="dropdown-item py-4">
                  <i class="far fa-user f-22"></i><br>Profile
                </a>
              </div>
              <div class="col-6 text-center">
                <a href="<?php echo base_url(); ?>User/dashboard" class="dropdown-item py-4">
                  <i class="fas fa-th f-22"></i><br>Dashboars
                </a>
              </div>
            </div>
          <!-- </div> -->
          <div class="dropdown-divider"></div>
          <a href="<?php echo base_url(); ?>User/logout" class="dropdown-item dropdown-footer"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
      </li>
    <!-- <li class="nav-item">
      <a class="nav-link" href="<?php echo base_url(); ?>User/logout">
        <i class="fas fa-sign-out-alt"></i>
      </a>
    </li> -->
    <li class="nav-item">
      <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#">
        <i class="fas fa-th-large"></i>
      </a>
    </li>
  </ul>
</nav>
<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <!-- Brand Logo -->
  <a href="#" class="brand-link">
    <img src="dist/img/AdminLTELogo.png" alt="" class="brand-image img-circle elevation-3"
         style="opacity: .8">
    <span class="brand-text font-weight-light"><?php echo $company_info[0]['company_name']; ?></span>
  </a>
  <!-- Sidebar -->
  <div class="sidebar">
    <!-- Sidebar user panel (optional) -->
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <div class="image">
        <!-- <img src="dist/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image"> -->
      </div>
      <div class="info">
        <a href="#" class="d-block"><?php echo $user_info[0]['user_name']; ?></a>
      </div>
    </div>
    <!-- Sidebar Menu -->
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Add icons to the links using the .nav-icon class with font-awesome or any other icon font library -->
        <li class="nav-item">
          <a href="<?php echo base_url(); ?>User/dashboard" class="nav-link">
            <i class="nav-icon fas fa-th"></i>
            <p>
              Dashboard
            </p>
          </a>
        </li>

        <li class="nav-item has-treeview">
          <a href="#" class="nav-link head">
            <i class="nav-icon fas fa-chart-pie"></i>
            <p>
              Company
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview" style="display: none;">
            <li class="nav-item">
              <a <?php if(isset($update_company)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>User/company_list" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Company Information</p>
              </a>
            </li>
            <li class="nav-item">
              <a <?php if(isset($update_user)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>User/user_information" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>User</p>
              </a>
            </li>
            <li class="nav-item">
              <a <?php if(isset($update_role)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>User/role" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Role</p>
              </a>
            </li>
          </ul>
        </li>

        <!-- <li class="nav-item has-treeview">
          <a href="#" class="nav-link head">
            <i class="nav-icon fas fa-list"></i>
            <p>
              Master
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview" style="display: none;">
            <li class="nav-item">
              <a <?php if(isset($update_unit)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Master/unit" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Unit</p>
              </a>
            </li>
            <li class="nav-item">
              <a <?php if(isset($update_brand)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Product/brand" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Brand</p>
              </a>
            </li>
            <li class="nav-item">
              <a <?php if(isset($update_salt)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Master/salt" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Salt</p>
              </a>
            </li>
            <li class="nav-item">
              <a <?php if(isset($update_packing)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Master/packing" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Packing</p>
              </a>
            </li>
            <li class="nav-item">
              <a <?php if(isset($update_edu_speciality)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Master/edu_speciality" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Education Specialty</p>
              </a>
            </li>
            <li class="nav-item">
              <a <?php if(isset($update_edu_stream)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Master/edu_stream" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Education Stream</p>
              </a>
            </li>
            <li class="nav-item">
              <a <?php if(isset($update_safety)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Master/safety" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Safety</p>
              </a>
            </li>
            <li class="nav-item">
              <a <?php if(isset($update_disease)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Master/disease" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Disease</p>
              </a>
            </li>
            <li class="nav-item">
              <a <?php if(isset($update_category)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Master/category" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Category</p>
              </a>
            </li>
            <li class="nav-item">
              <a <?php if(isset($update_group)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Master/group" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Group</p>
              </a>
            </li>
            <li class="nav-item">
              <a <?php if(isset($update_gst_slab)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Master/gst_slab" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>GST Slab</p>
              </a>
            </li>
          </ul>
        </li> -->

        <li class="nav-item has-treeview">
          <a href="#" class="nav-link head">
            <i class="nav-icon fas fa-flask"></i>
            <p>
              Hospital Master
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview" style="display: none;">
            <li class="nav-item">
              <a <?php if(isset($update_service)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Master/service" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Service</p>
              </a>
            </li>
            <li class="nav-item">
              <a <?php if(isset($update_treat_speciality)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Master/treat_speciality" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Treatment Speciality</p>
              </a>
            </li>
            <li class="nav-item">
              <a <?php if(isset($update_facility)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Master/facility" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Facility</p>
              </a>
            </li>
            <li class="nav-item">
              <a <?php if(isset($update_cov_treatment)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Hospital/cov_treatment" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>COVID Treatment</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo base_url(); ?>Hospital/available_bed" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Available Bed</p>
              </a>
            </li>
            <!-- <li class="nav-item">
              <a <?php if(isset($update_bed_type)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Master/bed_type" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Bed Type</p>
              </a>
            </li> -->
          </ul>
        </li>

        <!-- <li class="nav-item has-treeview">
          <a href="#" class="nav-link head">
            <i class="nav-icon fas fa-flask"></i>
            <p>
              Test Information
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview" style="display: none;">
            <li class="nav-item">
              <a <?php if(isset($update_test_group)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Master/test_group" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Test Group</p>
              </a>
            </li>
            <li class="nav-item">
              <a <?php if(isset($update_test)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Master/test" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Test</p>
              </a>
            </li>
          </ul>
        </li> -->

        <!-- Website -->
        <!-- <li class="nav-item has-treeview">
          <a href="#" class="nav-link head">
            <i class="nav-icon fas fa-globe"></i>
            <p>
              Website
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview" style="display: none;">
            <li class="nav-item">
              <a <?php if(isset($update_slider)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Master/slider" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Slider</p>
              </a>
            </li>
            <li class="nav-item">
              <a <?php if(isset($update_advt_banner)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Master/advt_banner" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Advertise Banner</p>
              </a>
            </li>
          </ul>
        </li> -->

        <li class="nav-item has-treeview">
          <a href="#" class="nav-link head">
            <i class="nav-icon fas fa-newspaper"></i>
            <p>
              Article
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview" style="display: none;">
            <li class="nav-item">
              <a <?php if(isset($update_article_category)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Product/article_category" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Article Category</p>
              </a>
            </li>
            <li class="nav-item">
              <a <?php if(isset($update_article)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Product/article" <?php } ?> class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Article</p>
              </a>
            </li>
          </ul>
        </li>

        <li class="nav-item">
          <a <?php if(isset($update_hospital)){ echo 'href="'.$act_link.'"'; } else{ ?> href="<?php echo base_url(); ?>Hospital/hospital" <?php } ?> class="nav-link">
            <i class="nav-icon fas fa-hospital-alt"></i>
            <p>
              Hospital
            </p>
          </a>
        </li>


      </nav>
    <!-- /.sidebar-menu -->
    </div>
  <!-- /.sidebar -->
  </aside>
